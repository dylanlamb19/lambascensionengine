/**
 * Create the single owner account from server env, only when the user table is empty.
 * Public sign-up stays disabled. Never import this from client code.
 */
import { randomUUID } from "node:crypto";
import { getSql } from "@/lib/db";

function env(key: string): string | undefined {
  const v = process.env[key]?.trim();
  return v || undefined;
}

function productionLike(): boolean {
  const n = (process.env.APP_ENV || process.env.NODE_ENV || "").toLowerCase();
  return n === "production";
}

export async function bootstrapOwnerIfNeeded(): Promise<{ created: boolean; reason: string }> {
  const email = env("OWNER_EMAIL")?.toLowerCase();
  const password = process.env.OWNER_PASSWORD;
  if (!email || !password) return { created: false, reason: "no_env" };
  if (productionLike() && (password === "changeme" || password === "change-me")) {
    console.error("[auth] Refusing to bootstrap owner with a default password in production.");
    return { created: false, reason: "default_password_blocked" };
  }

  const sql = await getSql();
  const existing = await sql<{ id: string }>`select id from "user" limit 1`;
  if (existing.length) return { created: false, reason: "owner_exists" };

  const { hashPassword } = await import("better-auth/crypto");
  const hash = await hashPassword(password);
  const now = new Date();
  const userId = randomUUID();
  const accountId = randomUUID();
  await sql`
    insert into "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt")
    values (${userId}, ${"Owner"}, ${email}, ${true}, ${now}, ${now})
  `;
  await sql`
    insert into "account" ("id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt")
    values (${accountId}, ${email}, ${"credential"}, ${userId}, ${hash}, ${now}, ${now})
  `;
  return { created: true, reason: "bootstrapped" };
}
