/**
 * Gmail (later): OAuth only. Never send without an explicit Approve.
 *
 * Connect: Google OAuth (gmail.send + gmail.readonly) stored server-side.
 * Send path: DRAFT → READY FOR REVIEW → you click Approve → SENT.
 * Inbound: poll/watch threads → if reply, set REPLIED, classify, draft a response, wait for you.
 * Bounce/unsubscribe: mark UNSUBSCRIBED / BOUNCED, add to suppression, stop sequence.
 * No fake open tracking.
 */
export const GMAIL_NOT_CONNECTED = "Gmail is not connected. Copy the draft, or connect Gmail later. Nothing is sent from this app yet.";
