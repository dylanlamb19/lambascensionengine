export type VoiceMode = "off" | "ptt" | "conversation";
export type InputMethod = "MANUAL" | "VOICE" | "AUTOMATION";
export type Risk = "LOW" | "MEDIUM" | "HIGH";

export type IntentName =
  | "GET_DAILY_TASKS"
  | "START_TASKS"
  | "NEXT_TASK"
  | "PREVIOUS_TASK"
  | "OPEN_PROSPECT"
  | "FIND_CLIENTS"
  | "RESEARCH_FURTHER"
  | "EXPLAIN_PROSPECT"
  | "READ_OUTREACH"
  | "APPROVE_PROSPECT"
  | "SKIP_PROSPECT"
  | "SHOW_EVIDENCE"
  | "READ_CALL_OPENER"
  | "MAKE_EMAIL_SHORTER"
  | "GO_BACK"
  | "CANCEL"
  | "STOP_LISTENING"
  | "SEND_EMAIL"
  | "CONFIRM"
  | "UNKNOWN";

export type ParsedIntent = {
  intent: IntentName;
  risk: Risk;
  companyQuery: string;
  confidence: number;
  raw: string;
  findVertical?: string;
  findLocation?: string;
  findCount?: number;
};

export type VoiceContext = {
  openUid: string | null;
  companies: { uid: string; name: string; score?: number }[];
};

export const HIGH_INTENTS: IntentName[] = ["SEND_EMAIL"];
export const MEDIUM_INTENTS: IntentName[] = ["APPROVE_PROSPECT", "SKIP_PROSPECT"];
