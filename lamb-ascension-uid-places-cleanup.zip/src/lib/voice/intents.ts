import type { IntentName, ParsedIntent, Risk, VoiceContext } from "./types.ts";
import { HIGH_INTENTS, MEDIUM_INTENTS } from "./types.ts";

function riskOf(intent: IntentName): Risk {
  if (HIGH_INTENTS.includes(intent)) return "HIGH";
  if (MEDIUM_INTENTS.includes(intent)) return "MEDIUM";
  return "LOW";
}

function hit(t: string, re: RegExp): boolean {
  return re.test(t);
}

export function parseSpokenCommand(raw: string): ParsedIntent {
  const t = (raw || "").toLowerCase().replace(/[?.!,]/g, " ").replace(/\s+/g, " ").trim();
  const base = { companyQuery: "", confidence: 0.9, raw };
  if (!t || t.length < 2) return { intent: "UNKNOWN", risk: "LOW", companyQuery: "", confidence: 0.1, raw };

  if (hit(t, /^(stop|cancel|never mind|nevermind|forget it)$/)) return { ...base, intent: t.includes("stop") && !t.includes("listening") && t === "stop" ? "STOP_LISTENING" : "CANCEL", risk: "LOW", confidence: 0.99 };
  if (hit(t, /stop listening|mute|turn off voice/)) return { ...base, intent: "STOP_LISTENING", risk: "LOW", confidence: 0.98 };
  if (hit(t, /^(stop|cancel|never mind|nevermind)$/)) return { ...base, intent: "CANCEL", risk: "LOW", confidence: 0.99 };

  if (hit(t, /confirm send|yes send it|confirm$/)) return { ...base, intent: "CONFIRM", risk: "HIGH", confidence: 0.85 };

  if (hit(t, /send (the |that )?(email|message|it)/)) return { ...base, intent: "SEND_EMAIL", risk: "HIGH", confidence: 0.92 };

  if (hit(t, /what('s| is) next|start my tasks|start tasks|what needs me|what do i need|good morning/)) {
    if (hit(t, /start/)) return { ...base, intent: "START_TASKS", risk: "LOW" };
    return { ...base, intent: "GET_DAILY_TASKS", risk: "LOW" };
  }
  if (hit(t, /start my tasks|start tasks|yes start|let's start|lets start/)) return { ...base, intent: "START_TASKS", risk: "LOW" };
  if (hit(t, /next (one|task|prospect)|go to the next|show me the next/)) return { ...base, intent: "NEXT_TASK", risk: "LOW" };
  if (hit(t, /previous|go back to the last/)) return { ...base, intent: "PREVIOUS_TASK", risk: "LOW" };
  if (hit(t, /go back|back$/)) return { ...base, intent: "GO_BACK", risk: "LOW" };

  if (hit(t, /open the strongest|strongest prospect/)) return { ...base, intent: "OPEN_PROSPECT", companyQuery: "__strongest__", risk: "LOW" };

  const findN = t.match(/find(?: me)?(?: (\d+))? (.+?) (?:companies |businesses |firms )?(?:in|near|around) (.+)$/);
  if (findN) {
    const count = findN[1] ? Math.min(50, Math.max(1, parseInt(findN[1], 10))) : 20;
    return {
      ...base,
      intent: "FIND_CLIENTS",
      risk: "LOW",
      findCount: count,
      findVertical: findN[2].trim(),
      findLocation: findN[3].trim(),
    };
  }
  if (hit(t, /find clients|find companies|find \d+|find high-ticket/)) return { ...base, intent: "FIND_CLIENTS", risk: "LOW" };

  if (hit(t, /research (them |it |this )?further|look them up further/)) return { ...base, intent: "RESEARCH_FURTHER", risk: "LOW" };
  if (hit(t, /research them|research this|look them up/)) return { ...base, intent: "RESEARCH_FURTHER", risk: "LOW" };

  if (hit(t, /read( me)? the (email|outreach|draft)|what('s| is) the email/)) return { ...base, intent: "READ_OUTREACH", risk: "LOW" };
  if (hit(t, /make (that |the )?email shorter|shorten the email/)) return { ...base, intent: "MAKE_EMAIL_SHORTER", risk: "LOW" };
  if (hit(t, /call opener|what should i say on the call|what to say/)) return { ...base, intent: "READ_CALL_OPENER", risk: "LOW" };
  if (hit(t, /show( me)? (the )?evidence|read the evidence/)) return { ...base, intent: "SHOW_EVIDENCE", risk: "LOW" };
  if (hit(t, /explain( this| why| the score| this company)|why (do you like|this company)|what don'?t we know/)) {
    return { ...base, intent: "EXPLAIN_PROSPECT", risk: "LOW" };
  }

  if (hit(t, /approve (the |this )?prospect|approve them|approve this/)) return { ...base, intent: "APPROVE_PROSPECT", risk: "MEDIUM" };
  if (hit(t, /skip (them|this|it)|do not contact/)) return { ...base, intent: "SKIP_PROSPECT", risk: "MEDIUM" };

  const open = t.match(/open (.+)/);
  if (open) return { ...base, intent: "OPEN_PROSPECT", companyQuery: open[1].trim(), risk: "LOW", confidence: 0.8 };

  if (hit(t, /show( me)? (my )?prospects|pipeline/)) return { ...base, intent: "GET_DAILY_TASKS", risk: "LOW", confidence: 0.7 };

  return { intent: "UNKNOWN", risk: "LOW", companyQuery: "", confidence: 0.2, raw };
}

export function resolveCompany(query: string, ctx: VoiceContext): { uids: string[]; needAsk: boolean } {
  const q = (query || "").toLowerCase().trim();
  if (!q && ctx.openUid) return { uids: [ctx.openUid], needAsk: false };
  if (!q) return { uids: [], needAsk: true };
  const hits = ctx.companies.filter((c) => c.name.toLowerCase().includes(q) || q.includes(c.name.toLowerCase().split(" ")[0] || "___"));
  if (hits.length === 1) return { uids: [hits[0].uid], needAsk: false };
  if (hits.length > 1) return { uids: hits.map((h) => h.uid), needAsk: true };
  return { uids: [], needAsk: true };
}

export function needsTarget(intent: IntentName): boolean {
  return [
    "OPEN_PROSPECT", "RESEARCH_FURTHER", "EXPLAIN_PROSPECT", "READ_OUTREACH",
    "APPROVE_PROSPECT", "SKIP_PROSPECT", "SHOW_EVIDENCE", "READ_CALL_OPENER",
    "MAKE_EMAIL_SHORTER", "SEND_EMAIL",
  ].includes(intent);
}

export function confirmPhraseOk(text: string): boolean {
  const t = (text || "").toLowerCase().replace(/[?.!,]/g, "").trim();
  return t === "confirm send" || t === "confirm";
}

export { riskOf };
