"use client";

import { useEffect, useState } from "react";
import {
  approveTestFollowupFn,
  chooseTestRecipientFn,
  confirmTestSendFn,
  connectionTestFn,
  googleStartFn,
  saveTestModeFn,
  syncTestRepliesFn,
  testBookingLinkFn,
  testBookSlotFn,
  testSettingsFn,
} from "@/lib/mail/actions";
import type { LiveCheck } from "@/lib/mail/test-mode";

type Ready = "ready" | "missing";
type View = {
  testMode: boolean;
  allowlist: string[];
  caps: { maxFirst: number; maxFollowups: number };
  integrations: Record<string, Ready | boolean>;
  worker?: { state: string; detail: string };
  gmailEmail: string;
  checks: LiveCheck[];
};

const LABELS: Record<string, string> = {
  googleOAuthClientId: "Google OAuth Client ID",
  googleOAuthClientSecret: "Google OAuth Client Secret",
  appSecret: "APP_SECRET",
  outreachJobSecret: "OUTREACH_JOB_SECRET",
  gmailConnection: "Gmail connection",
  calendarConnection: "Calendar connection",
};

function mark(ok: boolean) {
  return ok ? "🟢 Ready" : "🔴 Missing";
}

export function TestDesk({ onBack }: { onBack: () => void }) {
  const [data, setData] = useState<View | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [disableConfirm, setDisableConfirm] = useState("");
  const [probe, setProbe] = useState<Record<string, { ok: boolean; detail: string; email?: string }> | null>(null);
  const [step, setStep] = useState(1);
  const [preview, setPreview] = useState<{ subject?: string; body?: string } | null>(null);
  const [sendIds, setSendIds] = useState<{ messageId?: string; threadId?: string } | null>(null);
  const [followMsg, setFollowMsg] = useState("");
  const [replyMsg, setReplyMsg] = useState("");
  const [bookUrl, setBookUrl] = useState("");
  const [slots, setSlots] = useState<{ start: string; end: string; label: string }[]>([]);
  const [booked, setBooked] = useState("");

  async function refresh() {
    const r = await testSettingsFn();
    if (r.ok) {
      setData({
        testMode: r.testMode,
        allowlist: r.allowlist,
        caps: r.caps,
        integrations: r.integrations as View["integrations"],
        worker: r.worker,
        gmailEmail: r.gmailEmail,
        checks: r.checks,
      });
      setStep(r.state.step || 1);
      if (r.state.message_id) setSendIds({ messageId: r.state.message_id, threadId: r.state.thread_id || undefined });
    }
  }

  useEffect(() => { void refresh().catch(() => setErr("Could not load Test Mode settings.")); }, []);

  async function addEmail() {
    if (!data) return;
    setBusy("allow");
    setErr("");
    try {
      const r = await saveTestModeFn({ data: { allowlist: [...data.allowlist, newEmail] } });
      if (!r.ok) setErr(r.reason);
      else { setNewEmail(""); setData({ ...data, allowlist: r.allowlist, testMode: r.testMode, caps: r.caps, checks: r.checks, integrations: r.integrations as View["integrations"], gmailEmail: r.gmailEmail }); }
    } catch { setErr("Could not save the allowlist."); }
    setBusy("");
  }

  async function removeEmail(email: string) {
    if (!data) return;
    const r = await saveTestModeFn({ data: { allowlist: data.allowlist.filter((e) => e !== email) } });
    if (r.ok) setData({ ...data, allowlist: r.allowlist, checks: r.checks, integrations: r.integrations as View["integrations"], gmailEmail: r.gmailEmail, testMode: r.testMode, caps: r.caps });
  }

  if (!data) {
    return <section className="rounded-[14px] border border-line bg-surface p-5"><p>Loading Test Mode…</p></section>;
  }

  return (
    <div className="space-y-4">
      <section className="rounded-[14px] border border-[#7a6418] bg-[#2a220e] p-5">
        <p className="text-sm text-gold">TEST MODE {data.testMode ? "ON" : "OFF"}</p>
        <h2 className="font-display text-2xl">Safe live Gmail + Calendar test</h2>
        <p className="mt-2 text-sm">Only addresses on your test list can receive email. First contact still needs your confirmation. Daily cap while testing: {data.caps.maxFirst} first emails, {data.caps.maxFollowups} follow-ups.</p>
      </section>
      {err ? <div className="rounded-xl border border-bad/40 bg-[#2a1414] p-3 text-sm">{err}</div> : null}

      <section className="rounded-[14px] border border-line bg-surface p-5">
        <h3 className="font-display mb-2 text-lg">Integrations</h3>
        <p className="mb-3 text-sm text-muted">Secrets are never shown. Ready means the value is set, not that it is correct.</p>
        {Object.entries(LABELS).map(([k, label]) => (
          <p key={k} className="text-sm">{mark(data.integrations[k] === "ready")} {label}</p>
        ))}
        <p className="text-sm">{data.worker?.detail || "🔴 Worker not configured"}</p>
        {data.gmailEmail ? <p className="mt-2 text-sm text-muted">Connected Gmail: {data.gmailEmail}</p> : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" disabled={Boolean(busy)} onClick={() => {
            setBusy("gmail");
            void googleStartFn({ data: { kind: "gmail", origin: window.location.origin } }).then((r) => {
              if (!r.ok) setErr(r.reason);
              else window.location.href = r.url;
              setBusy("");
            }).catch(() => { setErr("Could not start Gmail connect."); setBusy(""); });
          }}>Connect Gmail</button>
          <button className="min-h-11 rounded-lg border border-line px-4" disabled={Boolean(busy)} onClick={() => {
            setBusy("cal");
            void googleStartFn({ data: { kind: "calendar", origin: window.location.origin } }).then((r) => {
              if (!r.ok) setErr(r.reason);
              else window.location.href = r.url;
              setBusy("");
            }).catch(() => { setErr("Could not start Calendar connect."); setBusy(""); });
          }}>Connect Google Calendar</button>
        </div>
        <button className="mt-3 min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" disabled={Boolean(busy)} onClick={() => {
          setBusy("probe");
          void connectionTestFn().then((r) => {
            setProbe({
              session: r.session,
              gmailToken: r.gmailToken,
              gmailIdentity: r.gmailIdentity,
              calendarToken: r.calendarToken,
              calendarFreeBusy: r.calendarFreeBusy,
              worker: r.worker,
            });
            setBusy("");
          }).catch(() => { setErr("Connection test did not finish. No email was sent."); setBusy(""); });
        }}>{busy === "probe" ? "Checking…" : "Run Connection Test"}</button>
        {probe ? (
          <div className="mt-3 space-y-1 text-sm">
            {Object.entries(probe).map(([k, v]) => (
              <p key={k}>{v.ok ? "✅" : "❌"} {v.detail}</p>
            ))}
            <p className="text-muted">This check does not send email.</p>
          </div>
        ) : null}
      </section>

      <section className="rounded-[14px] border border-line bg-surface p-5">
        <h3 className="font-display mb-2 text-lg">Test allowlist</h3>
        <p className="mb-3 text-sm text-muted">Emails you add here are the only addresses Lamb Ascension may send to while Test Mode is on.</p>
        {data.allowlist.length ? data.allowlist.map((e) => (
          <div key={e} className="flex items-center justify-between border-b border-line py-2">
            <span>{e}</span>
            <button className="min-h-11 rounded-lg border border-line px-3" onClick={() => void removeEmail(e)}>Remove</button>
          </div>
        )) : <p className="text-sm text-muted">Empty. Nothing can be sent until you add an address.</p>}
        <div className="mt-3 flex flex-wrap gap-2">
          <input className="min-h-11 flex-1 rounded-lg border border-line bg-surface2 px-3" placeholder="you@example.com" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
          <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" disabled={busy === "allow"} onClick={() => void addEmail()}>Add</button>
        </div>
      </section>

      <section className="rounded-[14px] border border-line bg-surface p-5">
        <h3 className="font-display mb-2 text-lg">Guided Test Sales Flow</h3>
        <p className="mb-3 text-sm text-muted">Step {Math.min(step, 11)} of 11. Each green check below requires real evidence.</p>

        <p className="text-sm font-semibold">STEP 1 — Choose an allowlisted test recipient</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {data.allowlist.map((e) => (
            <button key={e} className="min-h-11 rounded-lg border border-line px-3" onClick={() => {
              setBusy("choose");
              void chooseTestRecipientFn({ data: { recipient: e } }).then((r) => {
                if (!r.ok) setErr(r.reason);
                else { setPreview(r.preview || null); setStep(2); setErr(""); }
                setBusy("");
              });
            }}>{e}</button>
          ))}
        </div>

        <p className="mt-4 text-sm font-semibold">STEP 2 — Preview test first email</p>
        {preview ? (
          <div className="mt-2 rounded-lg border border-line bg-surface2 p-3 text-sm">
            <p>Subject: {preview.subject}</p>
            <pre className="mt-2 whitespace-pre-wrap font-sans">{preview.body}</pre>
          </div>
        ) : <p className="text-sm text-muted">Choose a recipient to see the preview.</p>}

        <p className="mt-4 text-sm font-semibold">STEP 3 — Confirm send</p>
        <button className="mt-2 min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" disabled={busy === "send" || !preview} onClick={() => {
          setBusy("send");
          void confirmTestSendFn().then((r) => {
            if (!r.ok) setErr(r.reason);
            else { setSendIds({ messageId: r.messageId, threadId: r.threadId }); setStep(4); setErr(""); }
            setBusy("");
            void refresh();
          });
        }}>{busy === "send" ? "Sending…" : "Confirm send"}</button>

        <p className="mt-4 text-sm font-semibold">STEP 4 — Verify Gmail IDs</p>
        {sendIds?.messageId ? (
          <p className="text-sm">Message ID: {sendIds.messageId}<br />Thread ID: {sendIds.threadId || "missing"}</p>
        ) : <p className="text-sm text-muted">Waiting for a confirmed send.</p>}

        <p className="mt-4 text-sm font-semibold">STEP 5 — Approve one test follow-up</p>
        <button className="mt-2 min-h-11 rounded-lg border border-line px-4" disabled={!sendIds?.messageId} onClick={() => {
          void approveTestFollowupFn().then((r) => {
            if (!r.ok) setErr(r.reason);
            else { setFollowMsg(`${r.pending} follow-up scheduled. It will only send to the allowlisted address.`); setStep(6); }
            void refresh();
          });
        }}>Approve test follow-up</button>
        {followMsg ? <p className="mt-2 text-sm">{followMsg}</p> : null}

        <p className="mt-4 text-sm font-semibold">STEP 6 — Reply from the recipient inbox</p>
        <p className="text-sm text-muted">Open the test inbox, reply to the thread with any short message, then come back.</p>

        <p className="mt-4 text-sm font-semibold">STEP 7 — Sync replies</p>
        <button className="mt-2 min-h-11 rounded-lg border border-line px-4" onClick={() => {
          void syncTestRepliesFn().then((r) => {
            setReplyMsg(`${r.replies} new reply(ies). Follow-ups left: ${r.followupsLeft}.`);
            setStep(8);
            void refresh();
          });
        }}>Sync replies</button>
        {replyMsg ? <p className="mt-2 text-sm">{replyMsg}</p> : null}

        <p className="mt-4 text-sm font-semibold">STEP 8 — Pending follow-up cancelled</p>
        <p className="text-sm text-muted">This turns green only if a follow-up existed and is gone after a real reply.</p>

        <p className="mt-4 text-sm font-semibold">STEP 9 — Generate a test booking link</p>
        <button className="mt-2 min-h-11 rounded-lg border border-line px-4" onClick={() => {
          void testBookingLinkFn({ data: { origin: window.location.origin } }).then((r) => {
            if (!r.ok) setErr(r.reason);
            else { setBookUrl(r.url); setSlots(r.slots); setStep(10); }
            void refresh();
          });
        }}>Create booking link</button>
        {bookUrl ? <p className="mt-2 break-all text-sm">{bookUrl}</p> : null}

        <p className="mt-4 text-sm font-semibold">STEP 10 — Book one offered time</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {slots.map((s) => (
            <button key={s.start} className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" onClick={() => {
              void testBookSlotFn({ data: { start: s.start, end: s.end } }).then((r) => {
                if (!r.ok) setErr(r.reason);
                else { setBooked(r.eventId); setStep(11); }
                void refresh();
              });
            }}>{s.label}</button>
          ))}
        </div>
        {booked ? <p className="mt-2 text-sm">Calendar event: {booked}</p> : null}

        <p className="mt-4 text-sm font-semibold">STEP 11 — Verify calendar + pipeline</p>
        <p className="text-sm text-muted">Pipeline sync is green only when the test record is Call Booked and a real event id exists.</p>
      </section>

      <section className="rounded-[14px] border border-line bg-surface p-5">
        <h3 className="font-display mb-2 text-lg">LIVE SALES SYSTEM TEST</h3>
        {data.checks.map((c) => (
          <p key={c.key} className="text-sm">{c.label} {c.ok ? "✅" : "❌"}</p>
        ))}
        <p className="mt-3 text-sm text-muted">Checks stay red until the matching live evidence is stored. They are not guessed.</p>
      </section>

      <section className="rounded-[14px] border border-line bg-surface p-5">
        <h3 className="font-display mb-2 text-lg">Turn Test Mode off</h3>
        <p className="mb-2 text-sm">It stays on until you type DISABLE and confirm. After that, normal send caps apply and the allowlist is no longer a gate.</p>
        <input className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" placeholder="Type DISABLE" value={disableConfirm} onChange={(e) => setDisableConfirm(e.target.value)} />
        <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => {
          void saveTestModeFn({ data: { testMode: false, confirm: disableConfirm } }).then((r) => {
            if (!r.ok) setErr(r.reason);
            else void refresh();
          });
        }}>Disable Test Mode</button>
      </section>

      <button className="min-h-11 rounded-lg border border-line px-4" onClick={onBack}>Back home</button>
    </div>
  );
}
