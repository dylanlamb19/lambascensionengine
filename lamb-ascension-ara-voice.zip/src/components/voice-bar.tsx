"use client";

import { useEffect, useRef, useState } from "react";
import type { VoiceMode } from "@/lib/voice/types";
import type { AraStatus } from "@/lib/voice/ara-client";
import { createRecognizer, permissionDeniedPlain, speak, speechSupported, stopSpeaking, ttsSupported } from "@/lib/voice/speech";
import { ARA_UNAVAILABLE } from "@/lib/voice/ara-context";

const MIN_REAL_CONFIDENCE = 0.4;

export function VoiceBar({
  mode,
  onMode,
  listening,
  you,
  reply,
  muted,
  onMuted,
  onTranscript,
  onListening,
  onStop,
  araStatus = "ready",
  araError = "",
}: {
  mode: VoiceMode;
  onMode: (m: VoiceMode) => void;
  listening: boolean;
  you: string;
  reply: string;
  muted: boolean;
  onMuted: (v: boolean) => void;
  onTranscript: (text: string, isFinal: boolean, confidence: number | undefined) => void;
  onListening?: (active: boolean) => void;
  onStop: () => void;
  araStatus?: AraStatus;
  araError?: string;
}) {
  const recRef = useRef<ReturnType<typeof createRecognizer>>(null);
  const [avail, setAvail] = useState(true);
  const [err, setErr] = useState("");
  const activeRef = useRef(false);
  const expanded = mode === "conversation";
  const araDown = Boolean(araError) || araStatus === "unavailable";

  useEffect(() => {
    setAvail(speechSupported());
  }, []);

  useEffect(() => {
    if (mode !== "ptt") {
      activeRef.current = false;
      recRef.current?.abort();
      if (mode === "off") {
        stopSpeaking();
        onListening?.(false);
      }
      return;
    }
    if (!speechSupported()) {
      setErr("Voice isn’t available in this browser. Use the buttons — everything still works.");
    }
  }, [mode]);

  function pttDown() {
    setErr("");
    if (!speechSupported()) {
      setErr("Voice isn’t available in this browser. Use the buttons.");
      return;
    }
    onMode("ptt");
    activeRef.current = false;
    const rec = recRef.current || createRecognizer();
    if (!rec) return;
    recRef.current = rec;
    rec.continuous = false;
    rec.onresult = (ev) => {
      let finalText = "";
      let finalConfidence: number | undefined;
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        if (ev.results[i].isFinal) {
          finalText += ev.results[i][0].transcript;
          finalConfidence = ev.results[i][0].confidence;
        }
      }
      if (finalText.trim()) {
        const low = typeof finalConfidence === "number" && finalConfidence > 0 && finalConfidence < MIN_REAL_CONFIDENCE;
        onTranscript(finalText.trim(), true, low ? finalConfidence : finalConfidence);
      }
    };
    rec.onerror = (ev) => { setErr(permissionDeniedPlain(ev.error)); onListening?.(false); };
    rec.onstart = () => onListening?.(true);
    rec.onend = () => onListening?.(false);
    try { rec.start(); } catch { setErr(permissionDeniedPlain("not-allowed")); }
  }

  function pttUp() {
    recRef.current?.stop();
  }

  const statusLabel =
    araDown
      ? ARA_UNAVAILABLE
      : mode === "conversation" && araStatus === "connecting"
        ? "Connecting…"
        : mode === "conversation" && araStatus === "speaking"
          ? "Ara is speaking"
          : mode === "conversation" && (listening || araStatus === "listening")
            ? "Ara — Listening"
            : mode === "ptt" && listening
              ? "Listening…"
              : "Ready";

  return (
    <div className="rounded-[14px] border border-line bg-surface px-3 py-2">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-display text-gold">🎙 Ara</span>
        <span className="text-sm text-muted">{statusLabel}</span>
        <button
          className={`min-h-11 rounded-lg border px-3 text-sm ${mode === "conversation" ? "border-gold bg-gold font-semibold text-[#16120a]" : "border-line"}`}
          onClick={() => onMode(mode === "conversation" ? "off" : "conversation")}
        >
          Talk
        </button>
        <button
          className="min-h-11 touch-none rounded-lg border border-line px-3 text-sm"
          style={{ touchAction: "none" }}
          onPointerDown={pttDown}
          onPointerUp={pttUp}
          onPointerCancel={pttUp}
          onPointerLeave={(e) => { if (e.buttons === 0) pttUp(); }}
        >
          Hold to speak
        </button>
        {mode !== "off" ? (
          <>
            <button className="min-h-11 rounded-lg border border-line px-3" onClick={onStop}>Stop</button>
            <button className="min-h-11 rounded-lg border border-line px-3" onClick={() => { onMuted(!muted); if (!muted) stopSpeaking(); }}>
              {muted ? "Unmute" : "Mute"}
            </button>
          </>
        ) : null}
      </div>
      {expanded ? (
        <div className="mt-2 text-sm">
          {you ? <p><b>You:</b> {you}</p> : null}
          {reply ? <p><b>Ara:</b> {reply}</p> : null}
        </div>
      ) : null}
      {err ? <p className="mt-2 text-sm text-bad">{err}</p> : null}
      {araDown ? <p className="mt-2 text-sm text-bad">{ARA_UNAVAILABLE}. Push to talk and buttons still work.</p> : null}
      {!avail && mode === "ptt" ? <p className="mt-2 text-sm">Voice isn’t available here. Buttons still work.</p> : null}
      {mode === "ptt" && !ttsSupported() ? <p className="mt-1 text-xs text-muted">This browser won’t speak replies aloud. You can still read them.</p> : null}
    </div>
  );
}

export { speak };
