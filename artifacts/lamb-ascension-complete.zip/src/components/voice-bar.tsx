"use client";

import { useEffect, useRef, useState } from "react";
import type { VoiceMode } from "@/lib/voice/types";
import { createRecognizer, permissionDeniedPlain, speak, speechSupported, stopSpeaking, ttsSupported } from "@/lib/voice/speech";

/**
 * Recognition confidence below this is treated as "didn't catch that" and
 * the transcript is dropped before it ever reaches intent parsing. Many
 * browsers report 0 (or omit the field) for results that DID work fine —
 * that is a "not implemented" sentinel, not a real low-confidence score —
 * so a 0/undefined confidence is deliberately NOT treated as low here; only
 * a genuine positive-but-low number is.
 */
const MIN_REAL_CONFIDENCE = 0.4;

export function VoiceBar({
  mode,
  onMode,
  listening,
  you,
  reply,
  muted,
  onMuted,
  onTranscript,
  onListening,
  onStop,
}: {
  mode: VoiceMode;
  onMode: (m: VoiceMode) => void;
  listening: boolean;
  you: string;
  reply: string;
  muted: boolean;
  onMuted: (v: boolean) => void;
  onTranscript: (text: string, isFinal: boolean, confidence: number | undefined) => void;
  /** Real recognizer lifecycle — fires on actual start/end/error, not on mode selection. */
  onListening?: (active: boolean) => void;
  onStop: () => void;
}) {
  const recRef = useRef<ReturnType<typeof createRecognizer>>(null);
  const [avail, setAvail] = useState(true);
  const [err, setErr] = useState("");
  // Whether THIS session (conversation mode) should keep listening. A ref,
  // not state: `onend` reads it at fire-time, and state captured in a
  // closure from whenever the effect ran would go stale exactly the way
  // the old `mode === "conversation"` check inside onend did — abort()
  // still fires `onend` asynchronously afterward, so a stale "yes, still in
  // conversation mode" reading there would restart the mic even after the
  // owner picked Off.
  const activeRef = useRef(false);

  useEffect(() => {
    setAvail(speechSupported());
  }, []);

  useEffect(() => {
    if (mode === "off") {
      activeRef.current = false;
      recRef.current?.abort();
      stopSpeaking();
      onListening?.(false);
      return;
    }
    if (!speechSupported()) {
      setErr("Voice isn’t available in this browser. Use the buttons — everything still works.");
      return;
    }
    const rec = createRecognizer();
    if (!rec) return;
    rec.continuous = mode === "conversation";
    rec.onresult = (ev) => {
      let finalText = "";
      let finalConfidence: number | undefined;
      let partial = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const piece = ev.results[i][0].transcript;
        if (ev.results[i].isFinal) {
          finalText += piece;
          finalConfidence = ev.results[i][0].confidence;
        } else partial += piece;
      }
      if (partial) onTranscript(partial, false, undefined);
      if (finalText.trim()) onTranscript(finalText.trim(), true, finalConfidence);
    };
    rec.onerror = (ev) => setErr(permissionDeniedPlain(ev.error));
    rec.onstart = () => onListening?.(true);
    rec.onend = () => {
      onListening?.(false);
      // Only restart if this effect's own session is still the active one
      // AND the mode is still conversation — activeRef is set false the
      // instant mode leaves "conversation" (above, and in the cleanup
      // below), so an onend that fires after abort() from a mode switch
      // sees activeRef.current === false and does not restart the mic.
      if (activeRef.current && mode === "conversation") {
        try { rec.start(); onListening?.(true); } catch { /* already started */ }
      }
    };
    recRef.current = rec;
    activeRef.current = mode === "conversation";
    if (mode === "conversation") {
      try { rec.start(); } catch { setErr(permissionDeniedPlain("not-allowed")); }
    }
    return () => {
      activeRef.current = false;
      rec.abort();
    };
  }, [mode]);

  function pttDown() {
    setErr("");
    if (!speechSupported()) {
      setErr("Voice isn’t available in this browser. Use the buttons.");
      return;
    }
    onMode("ptt");
    activeRef.current = false; // PTT is single-shot — never auto-restarts on end
    const rec = recRef.current || createRecognizer();
    if (!rec) return;
    recRef.current = rec;
    rec.continuous = false;
    rec.onresult = (ev) => {
      let finalText = "";
      let finalConfidence: number | undefined;
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        if (ev.results[i].isFinal) {
          finalText += ev.results[i][0].transcript;
          finalConfidence = ev.results[i][0].confidence;
        }
      }
      if (finalText.trim()) onTranscript(finalText.trim(), true, finalConfidence);
    };
    rec.onerror = (ev) => { setErr(permissionDeniedPlain(ev.error)); onListening?.(false); };
    rec.onstart = () => onListening?.(true);
    rec.onend = () => onListening?.(false);
    try { rec.start(); } catch { setErr(permissionDeniedPlain("not-allowed")); }
  }

  function pttUp() {
    recRef.current?.stop();
  }

  return (
    <div className="rounded-[14px] border border-line bg-surface p-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-sm text-muted">Voice</span>
        {(["off", "ptt", "conversation"] as const).map((m) => (
          <button
            key={m}
            className={`min-h-11 rounded-lg border px-3 text-sm ${mode === m ? "border-gold bg-gold font-semibold text-[#16120a]" : "border-line"}`}
            onClick={() => onMode(m)}
          >
            {m === "off" ? "Off" : m === "ptt" ? "Push to talk" : "Conversation"}
          </button>
        ))}
        {mode === "ptt" ? (
          <button
            className="min-h-11 touch-none rounded-lg bg-gold px-4 font-semibold text-[#16120a]"
            style={{ touchAction: "none" }}
            onPointerDown={pttDown}
            onPointerUp={pttUp}
            onPointerCancel={pttUp}
            onPointerLeave={(e) => { if (e.buttons === 0) pttUp(); }}
          >
            Hold to speak
          </button>
        ) : null}
        {mode !== "off" ? (
          <>
            <button className="min-h-11 rounded-lg border border-line px-3" onClick={onStop}>Stop listening</button>
            <button className="min-h-11 rounded-lg border border-line px-3" onClick={() => { onMuted(!muted); if (!muted) stopSpeaking(); }}>
              {muted ? "Unmute voice" : "Mute voice"}
            </button>
          </>
        ) : null}
      </div>
      {mode !== "off" && listening ? <p className="mt-2 text-sm text-gold">Listening…</p> : null}
      {you ? <p className="mt-1 text-sm"><b>You said:</b> {you}</p> : null}
      {reply ? <p className="mt-1 text-sm"><b>Lamb Ascension:</b> {reply}</p> : null}
      {err ? <p className="mt-2 text-sm text-bad">{err}</p> : null}
      {!avail && mode !== "off" ? <p className="mt-2 text-sm">Voice isn’t available here. Buttons still work.</p> : null}
      {mode !== "off" && !ttsSupported() ? <p className="mt-1 text-xs text-muted">This browser won’t speak replies aloud. You can still read them.</p> : null}
    </div>
  );
}

export { speak };
