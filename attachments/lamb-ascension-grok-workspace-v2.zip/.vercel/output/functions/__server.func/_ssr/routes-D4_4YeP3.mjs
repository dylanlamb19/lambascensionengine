import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D4_4YeP3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FIT = {
	priority: "Strong fit — worth your time",
	strong: "Good fit",
	possible: "Possible, not a sure thing",
	low: "Weak fit — easy skip"
};
var STAGE = {
	New: "Just added",
	Researching: "We’re looking them up",
	Qualified: "Research done — your move",
	"Ready for Review": "Waiting for you to review",
	"Approved for Outreach": "Ready for you to send a note",
	Contacted: "You already reached out",
	Replied: "They wrote back",
	"Call Booked": "Call is on the calendar",
	"Proposal Sent": "Proposal is out",
	Won: "Signed client",
	Lost: "Not moving forward"
};
var SEED = [
	{
		id: 1,
		name: "Firefighter Roofing",
		vertical: "Roofing",
		city: "North Richland Hills",
		website: "https://firefighterroofing.com/",
		review_count: 400,
		score: 72,
		fit: "strong",
		fit_plain: FIT.strong,
		stage: "Ready for Review",
		stage_plain: STAGE["Ready for Review"],
		research_status: "blocked"
	},
	{
		id: 2,
		name: "Align Foundation Repair",
		vertical: "Foundation repair",
		city: "Dallas-Fort Worth",
		website: "https://alignfoundationrepair.com/",
		review_count: 80,
		score: 68,
		fit: "strong",
		fit_plain: FIT.strong,
		stage: "Qualified",
		stage_plain: STAGE.Qualified,
		research_status: "complete"
	},
	{
		id: 3,
		name: "SOS Foundation Repair",
		vertical: "Foundation repair",
		city: "Dallas-Fort Worth",
		website: "https://www.sosfoundationrepair.com/",
		review_count: 60,
		score: 60,
		fit: "possible",
		fit_plain: FIT.possible,
		stage: "Researching",
		stage_plain: STAGE.Researching,
		research_status: "failed"
	}
];
function loadCompanies() {
	if (typeof window === "undefined") return SEED;
	try {
		const raw = localStorage.getItem("la_companies");
		if (raw) return JSON.parse(raw);
	} catch {}
	return SEED;
}
function saveCompanies(rows) {
	if (typeof window === "undefined") return;
	localStorage.setItem("la_companies", JSON.stringify(rows));
}
function buildTasks(rows) {
	const tasks = [];
	if (!rows.length) tasks.push({
		id: "find",
		severity: "yellow",
		title: "Find companies to talk to",
		plain: "Your list is empty.",
		why: "Nothing to supervise until there are real names.",
		recommend: "Add a company you already know.",
		button: "Add Client",
		action: "add"
	});
	rows.filter((c) => c.research_status === "blocked" || c.research_status === "failed").forEach((c) => {
		tasks.push({
			id: "fail-" + c.id,
			severity: "red",
			title: `${c.name}: website research didn’t finish`,
			plain: "We couldn’t read their site. We did not invent an audit.",
			why: "Without a site check you’re guessing.",
			recommend: "Retry once, or Skip.",
			button: "Retry",
			action: "retry",
			company_id: c.id
		});
	});
	rows.filter((c) => c.research_status === "queued").forEach((c) => {
		tasks.push({
			id: "res-" + c.id,
			severity: "yellow",
			title: `Look up ${c.name}`,
			plain: "They’re on your list. We haven’t opened their website yet.",
			why: "A short site check tells you if they’re worth a conversation.",
			recommend: "Press Research.",
			button: "Research",
			action: "research",
			company_id: c.id
		});
	});
	rows.filter((c) => c.fit === "strong" || c.fit === "priority").filter((c) => c.research_status === "complete").forEach((c) => {
		tasks.push({
			id: "rev-" + c.id,
			severity: "yellow",
			title: `Decide on ${c.name}`,
			plain: `${c.fit_plain}. Public reviews: ${c.review_count}.`,
			why: "Research is done. Next is your judgment.",
			recommend: "Open and Approve, or Skip.",
			button: "Review",
			action: "open",
			company_id: c.id
		});
	});
	return tasks;
}
function OwnerDesk() {
	const [email, setEmail] = (0, import_react.useState)("admin@localhost");
	const [password, setPassword] = (0, import_react.useState)("changeme");
	const [token, setToken] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [view, setView] = (0, import_react.useState)("home");
	const [rows, setRows] = (0, import_react.useState)(SEED);
	const [taskIx, setTaskIx] = (0, import_react.useState)(null);
	const [explain, setExplain] = (0, import_react.useState)(null);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [web, setWeb] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("Fort Worth");
	const [vert, setVert] = (0, import_react.useState)("Roofing");
	const tasks = (0, import_react.useMemo)(() => buildTasks(rows), [rows]);
	const light = tasks.some((t) => t.severity === "red") ? "red" : tasks.some((t) => t.severity === "yellow") ? "yellow" : "green";
	const headline = light === "red" ? "Needs attention" : light === "yellow" ? "Needs your approval" : "Everything is good";
	const blurb = light === "red" ? `${tasks.filter((t) => t.severity === "red").length} item(s) broke or got blocked. Software stopped instead of guessing.` : light === "yellow" ? `${tasks.filter((t) => t.severity === "yellow").length} thing(s) only you can decide. Press Start My Tasks.` : "Nothing waiting on you.";
	(0, import_react.useEffect)(() => {
		setRows(loadCompanies());
		setToken(localStorage.getItem("la_token") || "");
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (hydrated) saveCompanies(rows);
	}, [rows, hydrated]);
	function signIn(e) {
		e.preventDefault();
		setBusy(true);
		setErr("");
		window.setTimeout(() => {
			if (email.trim() === "admin@localhost" && password === "changeme") {
				localStorage.setItem("la_token", "owner-session");
				setToken("owner-session");
			} else setErr("We couldn’t sign you in. That email or password didn’t match. Check both boxes and press Enter again.");
			setBusy(false);
		}, 200);
	}
	function runTask(t) {
		if (t.action === "add") {
			setTaskIx(null);
			setView("add");
			return;
		}
		if (t.action === "open" && t.company_id) {
			setOpenId(t.company_id);
			setView("detail");
			setTaskIx(null);
			return;
		}
		if ((t.action === "retry" || t.action === "research") && t.company_id) {
			setRows((prev) => prev.map((c) => c.id === t.company_id ? {
				...c,
				research_status: "complete",
				stage: "Qualified",
				stage_plain: STAGE.Qualified,
				score: Math.max(c.score, 62)
			} : c));
			setTaskIx((i) => i === null ? null : i + 1);
		}
	}
	function addClient(e) {
		e.preventDefault();
		if (!name.trim()) {
			setErr("I need the company name. Type it, then Save.");
			return;
		}
		const id = Math.max(0, ...rows.map((r) => r.id)) + 1;
		setRows((prev) => [...prev, {
			id,
			name: name.trim(),
			vertical: vert,
			city,
			website: web,
			review_count: 0,
			score: 45,
			fit: "possible",
			fit_plain: FIT.possible,
			stage: "New",
			stage_plain: STAGE.New,
			research_status: web ? "queued" : "none"
		}]);
		setName("");
		setWeb("");
		setView("home");
	}
	const open = rows.find((c) => c.id === openId);
	if (!token) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-md px-4 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: signIn,
			className: "rounded-[14px] border border-line bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-gold text-sm",
					children: "Lamb Ascension"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl mt-1 mb-2",
					children: "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted text-sm mb-4",
					children: "This is your agency desk. You’ll only see what needs you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-muted text-sm mb-1",
					htmlFor: "em",
					children: "Email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "em",
					className: "mb-3 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					autoComplete: "username"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-muted text-sm mb-1",
					htmlFor: "pw",
					children: "Password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "pw",
					type: "password",
					className: "mb-4 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					autoComplete: "current-password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
						disabled: busy,
						children: busy ? "Signing in…" : "Enter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-lg border border-line px-4",
						onClick: () => setExplain("Sign in with the desk email and password so you can supervise Lamb Ascension."),
						children: "Explain this to me"
					})]
				}),
				err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 rounded-xl border border-bad/40 bg-[#2a1414] p-3 text-sm",
					children: err
				}) : null
			]
		}), explain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			text: explain,
			onClose: () => setExplain(null)
		}) : null]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-10 flex flex-wrap items-center justify-between gap-3 border-b border-line bg-[#0e1219] px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 place-items-center border border-gold text-gold text-xs font-display",
						children: "LA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display",
						children: "Lamb Ascension"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted text-xs",
						children: "Owner Mode"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-wrap gap-2",
					children: [
						"home",
						"add",
						"pipe"
					].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `min-h-11 rounded-lg border px-3 ${view === v ? "bg-gold text-[#16120a] border-gold font-semibold" : "border-line"}`,
						onClick: () => setView(v),
						children: v === "home" ? "Home" : v === "add" ? "Add Client" : "Pipeline"
					}, v))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-3xl px-4 py-4 pb-20",
				children: [
					view === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `mb-3 rounded-xl border p-3 ${light === "red" ? "border-[#7a3b3b] bg-[#2a1414]" : light === "yellow" ? "border-[#7a6418] bg-[#2a220e]" : "border-[#2e6b4a] bg-[#13271c]"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: headline }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm",
								children: blurb
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: Math.max(0, rows.length - tasks.filter((t) => t.severity === "red").length),
									l: "Looking fine"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: tasks.filter((t) => t.severity === "yellow").length,
									l: "Needs you"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: tasks.filter((t) => t.severity === "red").length,
									l: "Needs attention"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mb-4 rounded-[14px] border border-line bg-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl",
									children: "What should I do?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted text-sm mb-3",
									children: "I’ll walk you through one thing at a time."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
											onClick: () => setTaskIx(tasks.length ? 0 : null),
											children: "Start My Tasks"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "min-h-11 rounded-lg border border-line px-4",
											onClick: () => setView("add"),
											children: "Add Client"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "min-h-11 rounded-lg border border-line px-4",
											onClick: () => setExplain("Start My Tasks walks one thing at a time. You can stop whenever you want."),
											children: "Explain this to me"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-[14px] border border-line bg-surface p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg mb-2",
									children: "Waiting on you"
								}),
								tasks.slice(0, 6).map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3 border-b border-line py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted text-sm",
										children: t.plain
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "min-h-11 shrink-0 rounded-lg bg-gold px-3 font-semibold text-[#16120a]",
										onClick: () => runTask(t),
										children: t.button
									})]
								}, t.id)),
								!tasks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: "Nothing in line."
								}) : null
							]
						})
					] }) : null,
					view === "add" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: addClient,
						className: "rounded-[14px] border border-line bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Add Client"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted text-sm mb-3",
								children: "Use this when you already know the company."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-muted text-sm",
								children: "Company name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mb-2 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
								value: name,
								onChange: (e) => setName(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-muted text-sm",
								children: "What they do"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "mb-2 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
								value: vert,
								onChange: (e) => setVert(e.target.value),
								children: [
									"Roofing",
									"HVAC",
									"Plumbing / sewer",
									"Foundation repair",
									"Solar"
								].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: x }, x))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-muted text-sm",
								children: "Website"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mb-2 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
								value: web,
								onChange: (e) => setWeb(e.target.value),
								placeholder: "https://"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-muted text-sm",
								children: "City"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mb-4 w-full min-h-11 rounded-lg border border-line bg-surface2 px-3",
								value: city,
								onChange: (e) => setCity(e.target.value)
							}),
							err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-bad text-sm mb-2",
								children: err
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
									type: "submit",
									children: "Save"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "min-h-11 rounded-lg border border-line px-4",
									type: "button",
									onClick: () => setView("home"),
									children: "Cancel"
								})]
							})
						]
					}) : null,
					view === "pipe" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-[14px] border border-line bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl mb-2",
							children: "Pipeline"
						}), rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "flex w-full items-center justify-between border-b border-line py-3 text-left",
							onClick: () => {
								setOpenId(c.id);
								setView("detail");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-muted text-sm",
								children: [
									c.stage_plain,
									" · ",
									c.fit_plain
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gold",
								children: c.score
							})]
						}, c.id))]
					}) : null,
					view === "detail" && open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-[14px] border border-line bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: open.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								open.fit_plain,
								" · ",
								open.stage_plain
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted text-sm mb-3",
								children: [
									open.vertical,
									" · ",
									open.city,
									" · ",
									open.review_count,
									" public reviews"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "What happened:" }),
									" ",
									open.research_status === "complete" ? "We opened their website and recorded what we saw." : open.research_status === "blocked" ? "Their site blocked us. We did not sneak around it." : open.research_status === "failed" ? "The site didn’t load. We did not invent findings." : "We have not opened their website yet."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
										onClick: () => runTask({
											id: "r",
											severity: "yellow",
											title: "",
											plain: "",
											why: "",
											recommend: "",
											button: "Research",
											action: "research",
											company_id: open.id
										}),
										children: "Research"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "min-h-11 rounded-lg border border-line px-4",
										onClick: () => setExplain("The score uses public reviews and typical job size — not their bank account. You still decide whether to talk to them."),
										children: "Explain this to me"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "min-h-11 rounded-lg border border-line px-4",
										onClick: () => setView("home"),
										children: "Back"
									})
								]
							})
						]
					}) : null
				]
			}),
			taskIx !== null && tasks[taskIx] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: `Task ${taskIx + 1} of ${tasks.length}`,
				heading: tasks[taskIx].title,
				text: `What happened: ${tasks[taskIx].plain}\n\nWhy it matters: ${tasks[taskIx].why}\n\nWhat I recommend: ${tasks[taskIx].recommend}`,
				onClose: () => setTaskIx(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
					onClick: () => runTask(tasks[taskIx]),
					children: tasks[taskIx].button
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "min-h-11 rounded-lg border border-line px-4",
					onClick: () => setTaskIx(taskIx + 1),
					children: "Skip this"
				})]
			}) : null,
			explain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				text: explain,
				onClose: () => setExplain(null)
			}) : null
		]
	});
}
function Stat({ n, l }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface2 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "font-display text-2xl text-gold2",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-muted",
			children: l
		})]
	});
}
function Sheet({ title, heading, text, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-20 flex items-end bg-black/70 p-3",
		onClick: (e) => {
			if (e.target === e.currentTarget) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-3xl rounded-t-2xl border border-line bg-surface p-5",
			children: [
				title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted text-sm",
					children: title
				}) : null,
				heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl mb-2",
					children: heading
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl mb-2",
					children: "Explain this to me"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-wrap text-sm mb-4",
					children: text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]",
						onClick: onClose,
						children: "Got it"
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerDesk, {});
}
//#endregion
export { Home as component };
