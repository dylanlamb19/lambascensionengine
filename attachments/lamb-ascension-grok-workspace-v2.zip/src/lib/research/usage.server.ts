/**
 * Server-authoritative daily cap for paid contact-enrichment (Hunter) calls.
 *
 * The client must NEVER be trusted to report how many enrichment calls it
 * has already made today, or what today's cap is — a client can send
 * whatever numbers it wants in a request body. This module is the only
 * code that reads or writes the `enrichment_usage` table (see
 * migrations/0002_enrichment_usage.sql); `deepResearchFn` calls it instead
 * of trusting `data.caps.dailyEnrichmentUsed` / `dailyEnrichmentCap`.
 *
 * Server-only — imports `@/lib/db`, which throws if evaluated in the
 * browser. Only import this from a createServerFn handler.
 */
import { getSql } from "@/lib/db";

/** Default cap when DAILY_ENRICHMENT_CAP is unset. Matches the old client default. */
const DEFAULT_CAP = 10;

export function dailyEnrichmentCap(): number {
  const raw = process.env.DAILY_ENRICHMENT_CAP?.trim();
  const n = raw ? Number(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : DEFAULT_CAP;
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

/** How many enrichment calls this user has already made today. Read-only — does not reserve or increment. */
export async function enrichmentUsedToday(userId: string): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ count: number }>`
    select count from enrichment_usage where user_id = ${userId} and day = ${today()}
  `;
  return rows[0]?.count ?? 0;
}

/**
 * Atomically reserve one enrichment call for today, IF under the cap.
 * Returns true (and persists the increment) when the caller may proceed;
 * false when today's cap is already reached — in which case nothing is
 * written. Safe under concurrent requests: the increment only commits when
 * `count < cap` is still true at write time (`on conflict ... where`), so
 * two simultaneous requests can't both slip through the last slot.
 */
export async function tryReserveEnrichment(userId: string, cap: number): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ count: number }>`
    insert into enrichment_usage as u (user_id, day, count)
    values (${userId}, ${today()}, 1)
    on conflict (user_id, day) do update
      set count = u.count + 1
      where u.count < ${cap}
    returning count
  `;
  return rows.length > 0;
}
