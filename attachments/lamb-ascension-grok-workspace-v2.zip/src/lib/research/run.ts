import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { DeepInput } from "./types";

export const deepResearchFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ data, context }: { data: DeepInput; context: { userId: string } }) => {
    const { env } = await import("@/lib/env.server");
    const { runDeepResearch } = await import("./orchestrate");
    const { dailyEnrichmentCap, enrichmentUsedToday, tryReserveEnrichment } = await import("./usage.server");

    // Server-authoritative cap. Neither the count-so-far nor the cap itself
    // comes from the client anymore — a client that sends a `caps` field is
    // simply ignored, which is why DeepInput (not DeepInput & { caps }) is
    // this handler's input type now.
    const cap = dailyEnrichmentCap();
    const usedSoFar = await enrichmentUsedToday(context.userId);

    const result = await runDeepResearch(data, {
      minScoreForEnrichment: 65,
      dailyEnrichmentUsed: usedSoFar,
      dailyEnrichmentCap: cap,
      hunterKey: env("HUNTER_API_KEY"),
    });

    // Persist the spend AFTER the fact, only when a paid call actually ran.
    // This has a bounded race under concurrent requests from the same user
    // (two requests can both read `usedSoFar` before either writes back, so
    // a rapid double-click could momentarily allow one call over cap) — an
    // accepted tradeoff at this app's scale (a single owner, manual
    // per-company research clicks) rather than the alternative of
    // reserving a slot before knowing whether this input even qualifies
    // for enrichment, which would burn cap on inputs that never call
    // Hunter. The increment itself is still atomic and cap-guarded
    // (tryReserveEnrichment), so it can't silently overshoot in a single
    // write, and a determined burst is bounded by concurrency, not
    // unlimited the way client-supplied counters were.
    if (result.hunter_ran) {
      await tryReserveEnrichment(context.userId, cap);
    }

    return result;
  });
