from datetime import datetime, timedelta
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from .config import settings

bearer = HTTPBearer(auto_error=False)

# bcrypt is deliberately slow (tunable work factor) so a leaked hash or
# leaked app_secret can't be brute-forced the way a raw sha256 hash can.
_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(pw: str) -> str:
    return _pwd_context.hash(pw)

def is_legacy_hash(hashed: str) -> bool:
    """True for a hash produced by the old sha256(app_secret + pw) scheme,
    as opposed to a bcrypt hash. Callers use this to upgrade a user's stored
    hash to bcrypt right after a successful legacy verification."""
    return not hashed.startswith(("$2a$", "$2b$", "$2y$"))

def verify_password(pw: str, hashed: str) -> bool:
    # Tolerate old sha256(app_secret + pw) hashes left over from before this
    # change so existing users/admin rows aren't locked out. The caller
    # (see main.login) is responsible for calling hash_password() again and
    # saving the result once this returns True for a legacy hash, so the row
    # is upgraded to bcrypt on its next successful login.
    if is_legacy_hash(hashed):
        import hashlib, hmac
        legacy = hashlib.sha256((settings.app_secret + pw).encode()).hexdigest()
        return hmac.compare_digest(legacy, hashed)
    try:
        return _pwd_context.verify(pw, hashed)
    except ValueError:
        return False

def make_token(email: str) -> str:
    payload = {"sub": email, "exp": datetime.utcnow() + timedelta(days=7)}
    return jwt.encode(payload, settings.app_secret, algorithm="HS256")

def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> str:
    if creds is None:
        raise HTTPException(401, "Sign in required")
    try:
        data = jwt.decode(creds.credentials, settings.app_secret, algorithms=["HS256"])
        return data["sub"]
    except JWTError:
        raise HTTPException(401, "Invalid or expired session")
