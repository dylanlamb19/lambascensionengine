"""Tests for the production-safety guard, login rate limiting, and the
legacy sha256 -> bcrypt password upgrade path.

The production-safety checks are tested as a pure function against
throwaway Settings instances (no env-var/import-order dependence).

The rate-limit and rehash tests boot the real FastAPI app but do NOT rely on
DATABASE_URL / LOGIN_RATE_LIMIT_* env vars being read at import time --
app.db.engine/SessionLocal and app.main's copies of those names are bound
once, at first import, so if some other test file in the same pytest run
has already imported app.db (test_auditor_http.py -> app.services.auditor
-> app.models -> app.db does exactly this), setting env vars here would be
silently too late. Instead this monkeypatches the bound engine/SessionLocal
and the login limiter directly, which works regardless of import order.
"""
import hashlib
import tempfile
import unittest

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.config import Settings, production_safety_problems, enforce_production_safety


class ProductionSafetyTests(unittest.TestCase):
    def test_dev_env_never_blocked(self):
        s = Settings(app_env="development", app_secret="dev-secret-change-me", admin_password="changeme", frontend_origin="")
        self.assertEqual(production_safety_problems(s), [])
        enforce_production_safety(s)  # must not raise

    def test_production_blocks_default_secret(self):
        s = Settings(app_env="production", app_secret="dev-secret-change-me", admin_password="realpw123", frontend_origin="https://app.lambascension.com")
        problems = production_safety_problems(s)
        self.assertTrue(any("APP_SECRET" in p for p in problems))
        with self.assertRaises(RuntimeError):
            enforce_production_safety(s)

    def test_production_blocks_default_admin_password(self):
        s = Settings(app_env="production", app_secret="a-real-unique-secret", admin_password="changeme", frontend_origin="https://app.lambascension.com")
        problems = production_safety_problems(s)
        self.assertTrue(any("ADMIN_PASSWORD" in p for p in problems))

    def test_production_blocks_missing_frontend_origin(self):
        s = Settings(app_env="production", app_secret="a-real-unique-secret", admin_password="realpw123", frontend_origin="")
        problems = production_safety_problems(s)
        self.assertTrue(any("FRONTEND_ORIGIN" in p for p in problems))

    def test_production_passes_with_safe_settings(self):
        s = Settings(app_env="production", app_secret="a-real-unique-secret", admin_password="realpw123", frontend_origin="https://app.lambascension.com")
        self.assertEqual(production_safety_problems(s), [])
        enforce_production_safety(s)  # must not raise


class _AppTestCase(unittest.TestCase):
    """Boots the real app against a throwaway sqlite file, bypassing
    whatever engine/SessionLocal app.db happened to bind at its own import
    time, and with a fresh, isolated rate limiter."""

    @classmethod
    def setUpClass(cls):
        from app import db as db_module
        from app import main as main_module
        from app.main import _LoginRateLimiter

        cls._tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        cls._tmp.close()
        engine = create_engine(f"sqlite:///{cls._tmp.name}", connect_args={"check_same_thread": False})
        session_local = sessionmaker(bind=engine, autoflush=False, autocommit=False)

        # app.db and app.main each hold their own name bound at import time
        # ("from .db import engine, SessionLocal" copies the reference into
        # app.main's namespace) -- both have to be repointed.
        db_module.engine = engine
        db_module.SessionLocal = session_local
        main_module.engine = engine
        main_module.SessionLocal = session_local

        cls.limit = 3
        main_module._login_limiter = _LoginRateLimiter(max_attempts=cls.limit, window_seconds=60)

        cls.main = main_module
        main_module.startup()  # creates tables + admin user against the throwaway DB

        from fastapi.testclient import TestClient
        cls.client = TestClient(main_module.app)

    @classmethod
    def tearDownClass(cls):
        import os
        os.unlink(cls._tmp.name)


class LoginRateLimitTests(_AppTestCase):
    def test_too_many_attempts_returns_429(self):
        for _ in range(self.limit):
            r = self.client.post("/api/login", json={"email": "nobody@example.com", "password": "wrong"})
            self.assertEqual(r.status_code, 401)
        r = self.client.post("/api/login", json={"email": "nobody@example.com", "password": "wrong"})
        self.assertEqual(r.status_code, 429)

    def test_different_email_not_blocked_by_another_users_attempts(self):
        for _ in range(self.limit):
            self.client.post("/api/login", json={"email": "target@example.com", "password": "wrong"})
        r = self.client.post("/api/login", json={"email": "someone-else@example.com", "password": "wrong"})
        self.assertNotEqual(r.status_code, 429)


class LegacyPasswordUpgradeTests(_AppTestCase):
    def test_legacy_hash_upgraded_after_successful_login(self):
        from app.models import User

        email = "legacy-user@example.com"
        password = "correct horse battery staple"
        legacy_hash = hashlib.sha256((self.main.settings.app_secret + password).encode()).hexdigest()

        db = self.main.SessionLocal()
        try:
            db.add(User(email=email, password_hash=legacy_hash))
            db.commit()
        finally:
            db.close()

        r = self.client.post("/api/login", json={"email": email, "password": password})
        self.assertEqual(r.status_code, 200)
        self.assertIn("token", r.json())

        db = self.main.SessionLocal()
        try:
            row = db.query(User).filter_by(email=email).first()
            self.assertTrue(
                row.password_hash.startswith(("$2a$", "$2b$", "$2y$")),
                "password_hash was not upgraded to bcrypt after a successful login",
            )
        finally:
            db.close()

        # And the new bcrypt hash still logs the user in correctly.
        r2 = self.client.post("/api/login", json={"email": email, "password": password})
        self.assertEqual(r2.status_code, 200)


if __name__ == "__main__":
    unittest.main()
