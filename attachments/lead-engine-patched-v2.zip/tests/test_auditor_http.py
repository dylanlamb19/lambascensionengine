import socket
import unittest
from unittest.mock import MagicMock, patch

from app.services.ssrf import SsrfError
from app.services.auditor import fetch_url, _pin_dns
from app.config import settings


class FakeResp:
    """Stand-in for httpx.Response as returned by client.send(req, stream=True):
    body comes back through iter_bytes() instead of being pre-buffered on
    .content, and callers are expected to .close() it."""

    def __init__(self, status, headers=None, content=b"", url="https://example.com/", chunk_size=64):
        self.status_code = status
        self.headers = headers or {}
        self.url = url
        self.encoding = "utf-8"
        self._content = content
        self._chunk_size = chunk_size
        self.chunks_yielded = 0
        self.closed = False

    def iter_bytes(self):
        for i in range(0, len(self._content), self._chunk_size):
            self.chunks_yielded += 1
            yield self._content[i:i + self._chunk_size]

    def close(self):
        self.closed = True


class FakeRequest:
    """Stand-in for httpx.Request returned by client.build_request()."""
    def __init__(self):
        self.extensions = {}


class FetchTests(unittest.TestCase):
    @patch("app.services.auditor.validate_url", side_effect=lambda u, allow_relative_base=None: (u, "93.184.216.34") if str(u).startswith("http") else (_ for _ in ()).throw(SsrfError("invalid", "bad")))
    def test_https_ok(self, _v):
        html = b"<html><title>T</title></html>"
        with patch("app.services.auditor._client") as cli:
            inst = MagicMock()
            inst.build_request.return_value = FakeRequest()
            inst.send.return_value = FakeResp(200, content=html, url="https://example.com/")
            inst.__enter__.return_value = inst
            inst.__exit__.return_value = False
            cli.return_value = inst
            r = fetch_url("https://example.com/")
        self.assertTrue(r["ok"])
        self.assertTrue(r["https"])
        self.assertEqual(r["status"], 200)

    @patch("app.services.auditor.validate_url")
    def test_redirect_to_private_blocked(self, v):
        def val(u, allow_relative_base=None):
            if "127.0.0.1" in u:
                raise SsrfError("blocked", "private")
            return (u if u.startswith("http") else "https://example.com/" + u), "93.184.216.34"
        v.side_effect = val
        with patch("app.services.auditor._client") as cli:
            inst = MagicMock()
            inst.build_request.return_value = FakeRequest()
            inst.send.return_value = FakeResp(302, headers={"location": "http://127.0.0.1/"}, url="https://example.com/")
            inst.__enter__.return_value = inst
            inst.__exit__.return_value = False
            cli.return_value = inst
            r = fetch_url("https://example.com/")
        self.assertFalse(r["ok"])
        self.assertIn("redirect_blocked", r["error"])

    @patch("app.services.auditor.validate_url", side_effect=lambda u, allow_relative_base=None: (u, "93.184.216.34"))
    def test_timeout(self, _v):
        import httpx
        with patch("app.services.auditor._client") as cli:
            inst = MagicMock()
            inst.build_request.return_value = FakeRequest()
            inst.send.side_effect = httpx.TimeoutException("t")
            inst.__enter__.return_value = inst
            inst.__exit__.return_value = False
            cli.return_value = inst
            r = fetch_url("https://example.com/")
        self.assertFalse(r["ok"])
        self.assertEqual(r["error"], "timeout")

    # --- Regression: IP pinning must not leak into application-level URLs ---

    @patch("app.services.auditor.validate_url", side_effect=lambda u, allow_relative_base=None: (u, "93.184.216.34") if str(u).startswith("http") else (_ for _ in ()).throw(SsrfError("invalid", "bad")))
    def test_hostname_preserved_when_ip_pinned(self, _v):
        """https://example.com/ may connect to 93.184.216.34, but the
        auditor still records and analyzes https://example.com/ — not the
        IP — in url/final_url, and DNS pinning was actually active for the
        one hostname being fetched while the request was in flight."""
        html = b"<html><title>Real site</title></html>"
        seen_during_send = {}

        def fake_send(req, stream=False):
            # Prove the DNS pin was live for this exact hostname during the
            # call.
            seen_during_send["pinned"] = socket.getaddrinfo("example.com", 443)
            return FakeResp(200, content=html, url="https://example.com/")

        with patch("app.services.auditor._client") as cli:
            inst = MagicMock()
            inst.build_request.return_value = FakeRequest()
            inst.send.side_effect = fake_send
            inst.__enter__.return_value = inst
            inst.__exit__.return_value = False
            cli.return_value = inst
            r = fetch_url("https://example.com/")

        self.assertTrue(r["ok"])
        self.assertEqual(r["url"], "https://example.com/")
        self.assertEqual(r["final_url"], "https://example.com/")
        self.assertNotIn("93.184.216.34", r["url"])
        # getaddrinfo("example.com", ...) was pinned to the validated IP
        # while the request was being sent.
        self.assertEqual(seen_during_send["pinned"][0][4][0], "93.184.216.34")
        # And the pin is torn down again immediately afterwards.
        self.assertNotEqual(socket.getaddrinfo("127.0.0.1", 80)[0][4][0], "93.184.216.34")

    def test_dns_rebinding_protection(self):
        """_pin_dns forces resolution of exactly the pinned host to the
        validated IP, leaves every other host's resolution untouched, and
        fully restores the original resolver on exit — even a host that
        would otherwise resolve to a private/internal address during the
        window is unaffected, because it's a *different* host."""
        original = socket.getaddrinfo
        with _pin_dns("evil-rebinder.example", "203.0.113.9"):
            pinned = socket.getaddrinfo("evil-rebinder.example", 443)
            self.assertEqual(pinned[0][4][0], "203.0.113.9")
            # A different host is not silently rewritten to the pinned IP —
            # the pin is host-scoped.
            other = socket.getaddrinfo("localhost", 80)
            self.assertNotEqual(other[0][4][0], "203.0.113.9")
        self.assertIs(socket.getaddrinfo, original)

    # --- Streaming size cap ---

    @patch("app.services.auditor.validate_url", side_effect=lambda u, allow_relative_base=None: (u, "93.184.216.34"))
    def test_streamed_response_size_limit(self, _v):
        """A response larger than max_audit_bytes is rejected without ever
        materializing the full body, and the connection is closed instead
        of drained to completion."""
        oversized = b"x" * (settings.max_audit_bytes * 3)
        fake_resp = FakeResp(200, content=oversized, url="https://example.com/", chunk_size=1024)
        with patch("app.services.auditor._client") as cli:
            inst = MagicMock()
            inst.build_request.return_value = FakeRequest()
            inst.send.return_value = fake_resp
            inst.__enter__.return_value = inst
            inst.__exit__.return_value = False
            cli.return_value = inst
            r = fetch_url("https://example.com/")
        self.assertFalse(r["ok"])
        self.assertEqual(r["error"], "too_large")
        # Stopped early: didn't pull every chunk of a 3x-oversized body.
        total_possible_chunks = len(oversized) // 1024
        self.assertLess(fake_resp.chunks_yielded, total_possible_chunks)
        self.assertTrue(fake_resp.closed)


if __name__ == "__main__":
    unittest.main()
