import type { Prospect } from "@/lib/review-brief";
import { liveGmail } from "../google/gmail";
import { refreshAccess, type GoogleTokens } from "../google/oauth";
import { classifyReply, draftReply } from "../outreach/reply";
import { sendMail, idempotencyKey } from "./send";
import type { InputMethod, MailKind } from "./types";
import {
  activeSequence,
  audit,
  bumpUsage,
  claimDueFollowups,
  finishFollowup,
  getUsage,
  hasKey,
  insertMessage,
  insertReply,
  lastThread,
  listOpenThreads,
  loadTokens,
  markGoogleError,
  saveGoogleAccount,
  seenReplyIds,
  stopSequencesForProspect,
} from "./sql.server";
import { getProspectByUid } from "@/lib/prospects/repo.server";
import { emailCannotBecomeCommand } from "./untrusted";

async function accessFor(userId: string): Promise<GoogleTokens | null> {
  let tokens = await loadTokens(userId, "gmail");
  if (!tokens) return null;
  if (tokens.expiry && tokens.expiry < Date.now() + 30_000 && tokens.refresh_token) {
    try {
      const next = await refreshAccess(tokens.refresh_token);
      next.refresh_token = tokens.refresh_token;
      next.email = tokens.email;
      next.sub = tokens.sub;
      await saveGoogleAccount(userId, "gmail", next);
      tokens = next;
    } catch {
      await markGoogleError(userId, "gmail", "Gmail needs to be reconnected.");
      return null;
    }
  }
  return tokens;
}

export async function sendLive(opts: {
  userId: string;
  prospect: Prospect;
  kind: MailKind;
  method: InputMethod;
  to: string;
  subject: string;
  body: string;
  firstApproved: boolean;
  threadId?: string | null;
  sequenceId?: string | null;
}): Promise<{ ok: true; threadId: string; messageId: string } | { ok: false; reason: string }> {
  const uid = opts.prospect.uid || "";
  const tokens = await accessFor(opts.userId);
  const usage = await getUsage(opts.userId);
  const seq = await activeSequence(opts.userId, uid);
  const key = idempotencyKey(opts.userId, uid, opts.kind, opts.sequenceId || undefined);
  const already = await hasKey(opts.userId, key);
  const existingKeys = new Set<string>();
  if (already) existingKeys.add(key);
  const gmail = tokens ? liveGmail(tokens.access_token) : null;
  const result = await sendMail({
    userId: opts.userId,
    prospect: {
      uid,
      name: opts.prospect.name,
      suppressed: opts.prospect.suppressed,
      stage: opts.prospect.stage,
    },
    kind: opts.kind,
    method: opts.method,
    to: opts.to,
    subject: opts.subject,
    body: opts.body,
    threadId: opts.threadId || (await lastThread(opts.userId, uid)),
    sequenceId: opts.sequenceId,
    deps: {
      gmail,
      gmailConnected: Boolean(tokens),
      usage,
      caps: { maxFirst: 15, maxFollowups: 30 },
      firstApproved: opts.firstApproved,
      sequenceActive: seq || opts.kind === "email",
      bounced: false,
      unsubscribed: opts.prospect.stage === "Do Not Contact",
      existingKeys,
    },
  });
  if (!result.ok) {
    if (result.record) {
      await insertMessage({
        userId: opts.userId,
        prospectUid: uid,
        direction: "out",
        recipient: opts.to,
        subject: opts.subject,
        body: opts.body,
        status: result.record.status,
        kind: opts.kind,
        idempotencyKey: key,
        inputMethod: opts.method,
        sequenceId: opts.sequenceId,
      });
    }
    await audit(opts.userId, "send_failed", result.reason, { prospectUid: uid, method: opts.method });
    return { ok: false, reason: result.reason };
  }
  const ins = await insertMessage({
    userId: opts.userId,
    prospectUid: uid,
    gmailMessageId: result.record.gmailMessageId,
    gmailThreadId: result.record.gmailThreadId,
    direction: "out",
    recipient: opts.to,
    subject: opts.subject,
    body: opts.body,
    status: "SENT",
    kind: opts.kind,
    idempotencyKey: key,
    inputMethod: opts.method,
    sequenceId: opts.sequenceId,
    sentAt: result.record.sentAt,
  });
  if (ins === "duplicate") {
    return { ok: false, reason: "This message was already sent. We did not send it again." };
  }
  await bumpUsage(opts.userId, opts.kind === "email" ? "first" : "followup");
  await audit(opts.userId, "sent", `${opts.kind} sent`, {
    prospectUid: uid,
    method: opts.method,
    providerIds: result.record.gmailMessageId || "",
  });
  return { ok: true, threadId: result.record.gmailThreadId || "", messageId: result.record.gmailMessageId || "" };
}

export async function runDueFollowups(): Promise<{ sent: number; skipped: number }> {
  const due = await claimDueFollowups();
  let sent = 0;
  let skipped = 0;
  for (const job of due) {
    const prospect = await getProspectByUid(job.user_id, job.prospect_uid);
    if (!prospect || prospect.suppressed || prospect.stage === "Do Not Contact") {
      await finishFollowup(job.id, "cancelled");
      skipped += 1;
      continue;
    }
    const to = (prospect.contacts || []).find((c) => c.email && c.email.includes("@"))?.email || "";
    const pack = prospect.outreach;
    const msg = pack?.messages.find((m) => m.kind === job.step);
    const result = await sendLive({
      userId: job.user_id,
      prospect,
      kind: job.step as MailKind,
      method: "AUTOMATION",
      to,
      subject: msg?.subject || pack?.messages.find((m) => m.kind === "email")?.subject || prospect.name,
      body: msg?.body || "",
      firstApproved: true,
      threadId: job.gmail_thread_id,
      sequenceId: job.sequence_id,
    });
    if (result.ok) {
      await finishFollowup(job.id, "sent");
      sent += 1;
    } else {
      await finishFollowup(job.id, "failed");
      skipped += 1;
    }
  }
  return { sent, skipped };
}

export async function syncRepliesForUser(userId: string): Promise<{ ok: true; replies: number }> {
  const tokens = await accessFor(userId);
  if (!tokens) return { ok: true, replies: 0 };
  const gmail = liveGmail(tokens.access_token);
  const threads = await listOpenThreads(userId);
  const seen = await seenReplyIds(userId);
  let n = 0;
  for (const t of threads) {
    const msgs = (await gmail.listNewReplies?.(t.gmail_thread_id)) || [];
    for (const m of msgs) {
      if (seen.has(m.id)) continue;
      emailCannotBecomeCommand(m.body);
      const cls = classifyReply(m.body);
      const ins = await insertReply(userId, t.prospect_uid, m.id, cls, m.body);
      if (ins === "duplicate") continue;
      seen.add(m.id);
      n += 1;
      await stopSequencesForProspect(userId, t.prospect_uid);
      await audit(userId, "reply", `${cls}: follow-ups stopped`, { prospectUid: t.prospect_uid, method: "AUTOMATION", providerIds: m.id });
      const prospect = await getProspectByUid(userId, t.prospect_uid);
      if (cls === "UNSUBSCRIBE" && prospect) {
        prospect.suppressed = true;
        prospect.stage = "Do Not Contact";
        const { upsertProspects } = await import("@/lib/prospects/repo.server");
        await upsertProspects(userId, [prospect]);
      }
      void draftReply(cls, prospect?.name || "");
    }
  }
  return { ok: true, replies: n };
}

export async function tickOutreachWorker(): Promise<void> {
  await runDueFollowups();
}
