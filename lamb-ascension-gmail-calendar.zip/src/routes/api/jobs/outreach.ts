import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/jobs/outreach")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.OUTREACH_JOB_SECRET?.trim();
        if (secret) {
          const got = request.headers.get("x-job-secret") || "";
          if (got !== secret) return new Response("forbidden", { status: 401 });
        }
        const { runDueFollowups } = await import("@/lib/mail/live.server");
        const due = await runDueFollowups();
        return Response.json({ ok: true, ...due });
      },
    },
  },
});
