import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/book/$token")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const { getBookingLink, loadTokens } = await import("@/lib/mail/sql.server");
        const link = await getBookingLink(params.token);
        if (!link || link.status !== "open") {
          return Response.json({ ok: false, reason: "This booking link is not valid." });
        }
        const tokens = await loadTokens(link.user_id, "calendar");
        if (!tokens) return Response.json({ ok: false, reason: "Calendar is not connected for this owner." });
        const { listBusy } = await import("@/lib/google/calendar");
        const { openSlots } = await import("@/lib/calendar/slots");
        const from = new Date();
        const busy = await listBusy(tokens.access_token, from, new Date(from.getTime() + 14 * 86400000));
        const slots = openSlots({ from, busy, count: 3 }).map((s) => ({
          start: s.start.toISOString(),
          end: s.end.toISOString(),
          label: s.label,
        }));
        return Response.json({ ok: true, slots });
      },
      POST: async ({ params, request }) => {
        const { getBookingLink, loadTokens, saveCalendarEvent, audit } = await import("@/lib/mail/sql.server");
        const link = await getBookingLink(params.token);
        if (!link || link.status !== "open") {
          return Response.json({ ok: false, reason: "This booking link is not valid." });
        }
        const body = (await request.json()) as { start?: string; end?: string };
        const tokens = await loadTokens(link.user_id, "calendar");
        if (!tokens) return Response.json({ ok: false, reason: "Calendar is not connected." });
        const { createEvent } = await import("@/lib/google/calendar");
        const start = new Date(body.start || "");
        const end = new Date(body.end || "");
        if (Number.isNaN(start.getTime())) return Response.json({ ok: false, reason: "Pick a listed time." });
        const created = await createEvent(tokens.access_token, {
          title: "Lamb Ascension sales call",
          start,
          end,
        });
        if (!created.ok) return Response.json({ ok: false, reason: created.error });
        await saveCalendarEvent(link.user_id, link.prospect_uid, created.id, "Sales call", start, end);
        await audit(link.user_id, "booking_link", "Prospect booked a time", { prospectUid: link.prospect_uid, method: "AUTOMATION", providerIds: created.id });
        return Response.json({ ok: true });
      },
    },
  },
});
