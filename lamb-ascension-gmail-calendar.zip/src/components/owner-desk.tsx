"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { FIT, STAGE } from "@/lib/pipeline-copy";
import {
  approveIsPrimary,
  explainCompany,
  highValueTake,
  importantFindings,
  nextStepLabel,
  opportunities,
  recommendOffer,
  whyConsider,
  type Prospect,
} from "@/lib/review-brief";
import { SEED } from "@/lib/seed-prospects";
import { deepResearchFn } from "@/lib/research/run";
import { listProspectsFn, importProspectsFn, upsertProspectsFn } from "@/lib/prospects/sync";
import { matchExisting } from "@/lib/prospects/dedupe";
import { applyByUid, findByUid, patchByUid, withUids } from "@/lib/prospects/identity";
import { ensureUid, newUid, nextClientId } from "@/lib/prospects/ids";
import { findClientsFn } from "@/lib/discovery/run";
import { mapSpokenVertical } from "@/lib/discovery/places";
import { generateOutreach } from "@/lib/outreach/generate";
import { googleStatusFn, salesCountsFn, sendFirstEmailFn, stopSequenceFn, availabilityFn, nextCallFn } from "@/lib/mail/actions";
import { CallCard, OutreachDesk, PrepCard } from "@/components/outreach-desk";
import { VoiceBar } from "@/components/voice-bar";
import { ActionGate, makeActionId } from "@/lib/voice/idempotency";
import { confirmPhraseOk, confirmSendPhraseOk, confirmSchedulePhraseOk, parseSpokenCommand, resolveCompany } from "@/lib/voice/intents";
import { speak, stopSpeaking } from "@/lib/voice/speech";
import type { VoiceMode } from "@/lib/voice/types";
import { authClient, signOut as realSignOut } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

type Light = "green" | "yellow" | "red";
type Task = {
  id: string;
  severity: Light;
  title: string;
  plain: string;
  why: string;
  recommend: string;
  button: string;
  action: string;
  company_uid?: string;
};

const STORE = "la_companies_v5";
const USAGE = "la_enrich_usage_v1";

function loadCompanies(): Prospect[] {
  if (typeof window === "undefined") return SEED;
  try {
    const raw = localStorage.getItem(STORE);
    if (raw) return withUids(JSON.parse(raw) as Prospect[]);
  } catch {
    /* ignore */
  }
  return withUids(SEED);
}
function saveCompanies(rows: Prospect[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORE, JSON.stringify(rows));
}

function buildTasks(rows: Prospect[]): Task[] {
  const tasks: Task[] = [];
  if (!rows.length) {
    tasks.push({
      id: "find", severity: "yellow", title: "Find companies to talk to",
      plain: "Your list is empty.", why: "Nothing to supervise until there are real names.",
      recommend: "Add a company you already know.", button: "Add Client", action: "add",
    });
  }
  rows.filter((c) => c.research_status === "blocked" || c.research_status === "failed").forEach((c) => {
    tasks.push({
      id: "fail-" + (c.uid || c.id), severity: "red", title: `${c.name}: website research didn’t finish`,
      plain: "We couldn’t read their site. We did not invent an audit.",
      why: "Without a site check you’re guessing about their funnel.",
      recommend: "Open the review to see what we actually know, then Skip or try later.",
      button: "Review", action: "open", company_uid: c.uid,
    });
  });
  rows.filter((c) => c.research_status === "queued").forEach((c) => {
    tasks.push({
      id: "res-" + (c.uid || c.id), severity: "yellow", title: `Look up ${c.name}`,
      plain: "They’re on your list. We haven’t opened their website yet.",
      why: "A site check tells you if they’re worth a conversation.",
      recommend: "Open the company. Live website research is not run from this button in Owner Mode.",
      button: "Open", action: "open", company_uid: c.uid,
    });
  });
  rows.filter((c) => (c.fit === "strong" || c.fit === "priority") && (c.research_status === "complete" || c.research_status === "partial")).forEach((c) => {
    if (c.stage === "Approved for Outreach" || c.stage === "Do Not Contact" || c.stage === "Contacted" || c.stage === "Replied" || c.stage === "Call Booked") return;
    tasks.push({
      id: "rev-" + (c.uid || c.id), severity: "yellow", title: `Decide on ${c.name}`,
      plain: `${c.fit_plain}. ${c.is_demo ? "DEMO. " : ""}Public reviews: ${c.review_count}.`,
      why: "Research is done. The next step is your judgment.",
      recommend: "Read the review, then Approve or Skip.",
      button: "Review", action: "open", company_uid: c.uid,
    });
  });
  rows.filter((c) => c.stage === "Approved for Outreach" && !c.suppressed).forEach((c) => {
    tasks.push({
      id: "out-" + (c.uid || c.id), severity: "yellow",
      title: `Your message for ${c.name} is ready.`,
      plain: c.is_demo ? "DEMO record. Preview, edit, then approve. Nothing is sent automatically." : "Preview, edit, then approve. Nothing is sent automatically.",
      why: "The note was written from verified research. You still decide.",
      recommend: "Preview the message.",
      button: "Preview", action: "outreach", company_uid: c.uid,
    });
  });
  rows.filter((c) => c.stage === "Call Booked").forEach((c) => {
    tasks.push({
      id: "prep-" + (c.uid || c.id), severity: "yellow", title: `Prepare for the ${c.name} call`,
      plain: "A short prep page is ready. Answers are questions, not facts we already know.",
      why: "Don’t walk in cold.", recommend: "Open call prep.", button: "Call prep", action: "prep", company_uid: c.uid,
    });
  });
  return tasks;
}

export function OwnerDesk() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { user, isPending } = useCurrentUserState();
  const userId = user?.id;
  const [hydrated, setHydrated] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<"home" | "add" | "find" | "pipe" | "detail" | "outreach" | "call" | "prep">("home");
  const [rows, setRows] = useState<Prospect[]>(SEED);
  const [taskIx, setTaskIx] = useState<number | null>(null);
  const [explain, setExplain] = useState<string | null>(null);
  const [openUid, setOpenUid] = useState<string | null>(null);
  const [evidence, setEvidence] = useState(false);
  const [advanced, setAdvanced] = useState(false);
  const [name, setName] = useState("");
  const [web, setWeb] = useState("");
  const [city, setCity] = useState("Fort Worth");
  const [vert, setVert] = useState("Roofing");
  const [deepBusy, setDeepBusy] = useState(false);
  const [deepErr, setDeepErr] = useState("");
  const [syncErr, setSyncErr] = useState("");
  const [syncReady, setSyncReady] = useState(false);
  const [findBusy, setFindBusy] = useState(false);
  const [findMsg, setFindMsg] = useState("");
  const [findLimit, setFindLimit] = useState(20);
  const [findMore, setFindMore] = useState(false);
  const [google, setGoogle] = useState({ gmail: "missing" as "connected" | "missing" | "attention", calendar: "missing" as "connected" | "missing" | "attention", configured: false, gmailEmail: "", error: "" });
  const [sales, setSales] = useState({ ready: 0, followups: 0, replies: 0, calls: 0 });
  const [minRating, setMinRating] = useState(0);
  const [minReviews, setMinReviews] = useState(0);
  const persistTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [voiceMode, setVoiceMode] = useState<VoiceMode>("off");
  const [youSaid, setYouSaid] = useState("");
  const [voiceReply, setVoiceReply] = useState("");
  const [voiceMuted, setVoiceMuted] = useState(false);
  const [voiceListening, setVoiceListening] = useState(false);
  const gateRef = useRef(new ActionGate());

  const tasks = useMemo(() => buildTasks(rows), [rows]);
  const readyN = rows.filter((c) => c.stage === "Approved for Outreach" && !c.suppressed).length;
  const light: Light = tasks.some((t) => t.severity === "red") ? "red" : tasks.some((t) => t.severity === "yellow") ? "yellow" : "green";
  const headline = light === "red" ? "Needs attention" : light === "yellow" ? "Needs your approval" : "Everything is good";
  const blurb =
    light === "red"
      ? `${tasks.filter((t) => t.severity === "red").length} item(s) broke or got blocked. Software stopped instead of guessing.`
      : light === "yellow"
        ? `${tasks.filter((t) => t.severity === "yellow").length} thing(s) only you can decide. Press Start My Tasks.`
        : "Nothing waiting on you.";

  useEffect(() => {
    if (!userId) return;
    const local = loadCompanies();
    setRows(local);
    setHydrated(true);
    let cancelled = false;
    void (async () => {
      try {
        const remote = await listProspectsFn();
        if (cancelled || !remote.ok) throw new Error("list");
        if (remote.prospects.length) {
          const extra = local.filter((l) => !matchExisting(remote.prospects, l));
          if (extra.length) await importProspectsFn({ data: { prospects: extra } });
          const latest = extra.length ? await listProspectsFn() : remote;
          if (!cancelled && latest.ok) {
            setRows(latest.prospects);
            saveCompanies(latest.prospects);
          }
        } else if (local.length) {
          const imported = await importProspectsFn({ data: { prospects: local } });
          if (!cancelled && imported.ok && imported.prospects.length) {
            setRows(imported.prospects);
            saveCompanies(imported.prospects);
          }
        }
        if (!cancelled) setSyncErr("");
        try {
          const [g, s] = await Promise.all([googleStatusFn(), salesCountsFn()]);
          if (!cancelled && g.ok) setGoogle({ gmail: g.gmail, calendar: g.calendar, configured: g.configured, gmailEmail: g.gmailEmail, error: g.error });
          if (!cancelled && s.ok) setSales({ ready: s.ready, followups: s.followups, replies: s.replies, calls: s.calls });
        } catch {
          /* keep defaults */
        }
      } catch {
        if (!cancelled) setSyncErr("Lamb Ascension couldn’t load your companies from the server. Your local copy is still safe.");
      } finally {
        if (!cancelled) setSyncReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, [userId]);

  useEffect(() => {
    if (!hydrated) return;
    saveCompanies(rows);
    if (!syncReady || !userId) return;
    if (persistTimer.current) clearTimeout(persistTimer.current);
    persistTimer.current = setTimeout(() => {
      void upsertProspectsFn({ data: { prospects: rows } })
        .then((r) => {
          if (r.ok) setSyncErr("");
          else setSyncErr("Lamb Ascension couldn’t save this change to the server. Your local copy is still safe.");
        })
        .catch(() => setSyncErr("Lamb Ascension couldn’t save this change to the server. Your local copy is still safe."));
    }, 400);
  }, [rows, hydrated, syncReady, userId]);

  async function connectGoogle(kind: "gmail" | "calendar") {
    try {
      const res = await (await import("@/lib/mail/actions")).googleStartFn({ data: { kind, origin: window.location.origin } });
      if (!res.ok) {
        setExplain(res.reason);
        return;
      }
      window.location.assign(res.url);
    } catch {
      setExplain("Could not start Google sign-in. Nothing was connected.");
    }
  }

  function signIn(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    void (async () => {
      const { data, error } = await authClient.signIn.email({ email: email.trim(), password });
      if (data && !error) {
        setBusy(false);
        return;
      }
      setErr("We couldn't sign you in. Check the email and password, then press Enter.");
      setBusy(false);
    })();
  }

  function runTask(t: Task) {
    if (t.action === "add") { setTaskIx(null); setView("add"); return; }
    if (t.action === "open" && t.company_uid) {
      setOpenUid(t.company_uid);
      setEvidence(false);
      setAdvanced(false);
      setView("detail");
      setTaskIx(null);
      return;
    }
    if (t.action === "outreach" && t.company_uid) {
      const c = findByUid(rows, t.company_uid);
      if (c) {
        const pack = c.outreach?.fingerprint === generateOutreach(c).fingerprint ? c.outreach : generateOutreach(c);
        patchCompany({ ...c, outreach: pack });
        setOpenUid(c.uid || null);
        setView("outreach");
      }
      setTaskIx(null);
      return;
    }
    if (t.action === "prep" && t.company_uid) {
      setOpenUid(t.company_uid);
      setView("prep");
      setTaskIx(null);
    }
  }

  function patchCompany(next: Prospect) {
    setRows((prev) => patchByUid(prev, ensureUid(next)));
  }

  function say(text: string) {
    setVoiceReply(text);
    speak(text, voiceMuted);
  }

  function onVoiceTranscript(text: string, isFinal: boolean, confidence: number | undefined) {
    setYouSaid(text);
    if (!isFinal) return;
    // Real acoustic confidence from the browser's SpeechRecognition API, not
    // the parser's own pattern-match confidence below. Many browsers report
    // 0 or omit this for perfectly good results (no real signal), so only a
    // genuine positive-but-low number counts as "didn't catch that" — 0 or
    // undefined falls through to the parser's own confidence check instead.
    if (typeof confidence === "number" && confidence > 0 && confidence < 0.4) {
      say("I didn't catch that. Can you say it again?");
      return;
    }
    const parsed = parseSpokenCommand(text);
    if (parsed.confidence < 0.45 || parsed.intent === "UNKNOWN") {
      say("I didn't catch that. Can you say it again?");
      return;
    }
    const id = makeActionId(parsed.intent, openUid, text);
    if (gateRef.current.seen(id)) return;

    if (parsed.intent === "STOP_LISTENING" || parsed.intent === "CANCEL") {
      gateRef.current.cancel();
      stopSpeaking();
      if (parsed.intent === "STOP_LISTENING") setVoiceMode("off");
      say("Okay. Stopped.");
      return;
    }
    if (parsed.intent === "CONFIRM") {
      const pending = gateRef.current.consumeConfirm(openUid);
      if (!pending.ok) {
        say(pending.expired ? "That confirmation timed out. Say it again if you still want to." : "There’s nothing waiting to confirm.");
        return;
      }
      if (pending.intent === "SEND_EMAIL") {
        if (!confirmSendPhraseOk(text)) {
          say("I need you to say Confirm send, or Cancel. Nothing was sent.");
          return;
        }
        const co = findByUid(rows, pending.target);
        if (co) void doSend(co, "VOICE");
        return;
      }
      if (pending.intent === "SCHEDULE_CALL") {
        if (!confirmSchedulePhraseOk(text)) {
          say("I need you to say Confirm schedule, or Cancel. Nothing was booked.");
          return;
        }
        say("Say the time again from the list, then I’ll book it from the buttons. Nothing was booked yet.");
        return;
      }
      if (!confirmPhraseOk(text)) {
        say("I need you to say Confirm, or Cancel.");
        return;
      }
      if (pending.intent === "APPROVE_PROSPECT" && pending.target != null) {
        const co = findByUid(rows, pending.target);
        if (co) approveProspect(co, "VOICE");
        return;
      }
      if (pending.intent === "SKIP_PROSPECT" && pending.target != null) {
        const co = findByUid(rows, pending.target);
        if (co) skipProspect(co, "VOICE");
        return;
      }
      say("That confirmation doesn’t match. Nothing was changed.");
      return;
    }

    const ctx = { openUid, companies: rows.map((r) => ({ uid: r.uid || "", name: r.name, score: r.score })) };
    let targetUid = openUid;
    if (parsed.companyQuery && parsed.companyQuery !== "__strongest__") {
      const res = resolveCompany(parsed.companyQuery, ctx);
      if (res.needAsk) {
        say("Which company do you mean?");
        return;
      }
      targetUid = res.uids[0] ?? null;
    } else if (parsed.intent !== "GET_DAILY_TASKS" && parsed.intent !== "START_TASKS" && parsed.intent !== "FIND_CLIENTS" && parsed.intent !== "NEXT_TASK" && parsed.intent !== "PREVIOUS_TASK" && parsed.intent !== "GO_BACK" && parsed.companyQuery !== "__strongest__") {
      const res = resolveCompany("", ctx);
      if (res.needAsk) {
        say("Which company do you mean?");
        return;
      }
      targetUid = res.uids[0] ?? openUid;
    }
    const co = findByUid(rows, targetUid);

    if (parsed.intent === "GET_DAILY_TASKS") {
      // Mid-flow inside Start My Tasks, "what's next" means the next task,
      // not a restart of the daily summary — otherwise it silently threw
      // the owner back to task zero every time they used that phrase.
      if (taskIx != null) {
        setTaskIx((n) => {
          const next = n == null ? 0 : n + 1;
          const t = tasks[next];
          say(t ? t.title : "That was the last one.");
          return t ? next : n;
        });
        return;
      }
      say(`You have ${tasks.length} thing${tasks.length === 1 ? "" : "s"} that need you. ${readyN ? `${readyN} ready to contact. ` : ""}Would you like to start?`);
      return;
    }
    if (parsed.intent === "START_TASKS") {
      setTaskIx(tasks.length ? 0 : null);
      if (!tasks.length) say("Nothing waiting on you.");
      else say(`${tasks[0].title}. ${tasks[0].plain}`);
      return;
    }
    if (parsed.intent === "NEXT_TASK") {
      setTaskIx((n) => {
        const next = n == null ? 0 : n + 1;
        const t = tasks[next];
        say(t ? t.title : "That was the last one.");
        return t ? next : n;
      });
      return;
    }
    if (parsed.intent === "PREVIOUS_TASK") {
      setTaskIx((n) => {
        if (n == null || n <= 0) {
          say("You're already at the first one.");
          return n;
        }
        const prev = n - 1;
        say(tasks[prev]?.title || "Back to the first one.");
        return prev;
      });
      return;
    }
    if (parsed.intent === "FIND_CLIENTS") {
      setView("find");
      if (parsed.findVertical) setVert(mapSpokenVertical(parsed.findVertical));
      if (parsed.findLocation) setCity(parsed.findLocation);
      if (parsed.findCount) setFindLimit(parsed.findCount);
      if (parsed.findVertical && parsed.findLocation) {
        const v = mapSpokenVertical(parsed.findVertical);
        const loc = parsed.findLocation;
        const n = parsed.findCount || 20;
        say(`Looking for ${n} ${v} companies in ${loc}.`);
        void runFind({ vertical: v, location: loc, limit: n });
      } else {
        say("What kind of company, and where?");
      }
      return;
    }
    if (parsed.intent === "GO_BACK") {
      setView("home");
      say("Back home.");
      return;
    }
    if (parsed.intent === "OPEN_PROSPECT" && parsed.companyQuery === "__strongest__") {
      const target = rows.reduce<(typeof rows)[number] | null>((best, c) => (!best || c.score > best.score ? c : best), null);
      if (!target) { say("I don’t have a prospect to open yet."); return; }
      setOpenUid(target.uid || null); setEvidence(false); setView("detail");
      say(`${target.name}. ${target.stage_plain}.`);
      return;
    }
    if (!co) {
      say("Which company do you mean?");
      return;
    }
    if (parsed.intent === "OPEN_PROSPECT") {
      setOpenUid(co.uid || null); setEvidence(false); setView("detail");
      say(`${co.name}. ${co.stage_plain}.`);
      return;
    }
    if (parsed.intent === "EXPLAIN_PROSPECT") {
      setOpenUid(co.uid || null);
      setExplain(explainCompany(co));
      say(explainCompany(co).slice(0, 280));
      return;
    }
    if (parsed.intent === "RESEARCH_FURTHER") {
      setOpenUid(co.uid || null);
      void researchFurther(co.uid || "");
      say(`Researching ${co.name} further. I’ll use public sources only.`);
      return;
    }
    if (parsed.intent === "SHOW_EVIDENCE") {
      setOpenUid(co.uid || null); setEvidence(true); setView("detail");
      say("Evidence is on the review page.");
      return;
    }
    if (parsed.intent === "READ_OUTREACH") {
      const pack = co.outreach || generateOutreach(co);
      patchCompany({ ...co, outreach: pack });
      setOpenUid(co.uid || null); setView("outreach");
      say(pack.messages.find((m) => m.kind === "email")?.body || "No draft yet.");
      return;
    }
    if (parsed.intent === "MAKE_EMAIL_SHORTER") {
      const pack = co.outreach || generateOutreach(co);
      const email = pack.messages.find((m) => m.kind === "email");
      if (!email) { say("No email draft yet."); return; }
      const shorter = email.body.split("\n").filter(Boolean).slice(0, 6).join("\n");
      patchCompany({
        ...co,
        outreach: { ...pack, messages: pack.messages.map((m) => m.kind === "email" ? { ...m, body: shorter } : m) },
        history: [...(co.history || []), { at: new Date().toISOString(), action: "edit_email", detail: "Shortened draft (VOICE). Not sent." }],
      });
      setOpenUid(co.uid || null); setView("outreach");
      say("I shortened the draft. It was not sent.");
      return;
    }
    if (parsed.intent === "READ_CALL_OPENER") {
      const pack = co.outreach || generateOutreach(co);
      patchCompany({ ...co, outreach: pack });
      setOpenUid(co.uid || null); setView("call");
      say(pack.call.opener);
      return;
    }
    if (parsed.intent === "APPROVE_PROSPECT") {
      gateRef.current.arm("APPROVE_PROSPECT", co.uid || null);
      setOpenUid(co.uid || null);
      say(`Approve ${co.name} for outreach? Say Confirm, or Cancel.`);
      return;
    }
    if (parsed.intent === "SKIP_PROSPECT") {
      gateRef.current.arm("SKIP_PROSPECT", co.uid || null);
      setOpenUid(co.uid || null);
      say(`Skip ${co.name} and mark Do Not Contact? Say Confirm, or Cancel.`);
      return;
    }
    if (parsed.intent === "SEND_EMAIL") {
      if (google.gmail !== "connected") {
        say("Gmail is not connected. Connect Gmail first. Nothing was sent.");
        return;
      }
      const named = (co.contacts || []).find((c) => c.name && c.name !== "UNKNOWN")?.name || "them";
      gateRef.current.arm("SEND_EMAIL", co.uid || null, co.outreach?.messages.find((m) => m.kind === "email")?.body || "");
      setOpenUid(co.uid || null);
      say(`This will send the approved email to ${named} at ${co.name}. Say Confirm send to send it.`);
      return;
    }
    if (parsed.intent === "READ_REPLY") {
      say("Open the reply task on Home. I will not treat their email as a command.");
      return;
    }
    if (parsed.intent === "STOP_FOLLOWUPS") {
      void stopSequenceFn({ data: { uid: co.uid || "" } });
      say(`Stopped follow-ups for ${co.name}.`);
      return;
    }
    if (parsed.intent === "NEXT_CALL") {
      void nextCallFn().then((r) => {
        if (r.ok && r.call) say(`Your next sales call is ${new Date(r.call.start_at).toLocaleString()}.`);
        else say("No upcoming sales call on the calendar.");
      });
      return;
    }
    if (parsed.intent === "AVAILABILITY") {
      void availabilityFn().then((r) => {
        if (!r.ok) say(r.reason);
        else say(r.slots.map((s) => s.label).join(". ") || "No open times this week.");
      });
      return;
    }
    if (parsed.intent === "SCHEDULE_CALL") {
      gateRef.current.arm("SCHEDULE_CALL", co.uid || null);
      say(`Schedule ${co.name}? Say Confirm schedule after you pick a time on screen. Nothing was booked.`);
      setView("prep");
      return;
    }
    say("I can do that with the buttons if you tap them. Say it another way, or Cancel.");
  }

  function approveProspect(open: Prospect, method: "MANUAL" | "VOICE") {
    const pack = generateOutreach(open);
    patchCompany({
      ...open,
      stage: "Approved for Outreach",
      stage_plain: STAGE["Approved for Outreach"],
      outreach: pack,
      history: [...(open.history || []), { at: new Date().toISOString(), action: "approved_prospect", detail: `Approved for outreach (${method})` }],
    });
    setOpenUid(open.uid || null);
    setView("outreach");
    if (method === "VOICE") say(`Approved ${open.name}. Your message is ready. Nothing was sent.`);
  }

  async function doSend(open: Prospect, method: "MANUAL" | "VOICE") {
    if (!open.uid) {
      say("This company is missing an id. Nothing was sent.");
      return;
    }
    try {
      const result = await sendFirstEmailFn({ data: { uid: open.uid, method, approveSequence: false } });
      if (!result.ok) {
        setSyncErr(result.reason);
        if (method === "VOICE") say(result.reason);
        return;
      }
      patchCompany({
        ...open,
        stage: "Contacted",
        stage_plain: "You already reached out",
        outreach: open.outreach
          ? { ...open.outreach, messages: open.outreach.messages.map((m) => m.kind === "email" ? { ...m, state: "SENT" } : m) }
          : open.outreach,
        history: [...(open.history || []), { at: new Date().toISOString(), action: "sent", detail: `Gmail confirmed send (${method})` }],
      });
      if (method === "VOICE") say(`Sent to ${open.name}.`);
    } catch {
      setSyncErr("Lamb Ascension could not send this email. It has NOT been marked sent.");
      if (method === "VOICE") say("Could not send. It has not been marked sent.");
    }
  }

  function skipProspect(open: Prospect, method: "MANUAL" | "VOICE") {
    patchCompany({
      ...open,
      stage: "Do Not Contact",
      stage_plain: STAGE["Do Not Contact"],
      suppressed: true,
      history: [...(open.history || []), { at: new Date().toISOString(), action: "skip", detail: `Do Not Contact (${method})` }],
    });
    setView("home");
    if (open.uid) void stopSequenceFn({ data: { uid: open.uid } });
    if (method === "VOICE") say(`${open.name} is on Do Not Contact.`);
  }

  async function researchFurther(uid: string) {
    const company = findByUid(rows, uid);
    if (!company) return;
    setDeepBusy(true);
    setDeepErr("");
    try {
      // Display-only from here down: `used` is a local cache for the UI so
      // it can show a running count without waiting on a round trip. It no
      // longer gates anything — the server enforces the real daily cap
      // independently (src/lib/research/usage.server.ts) regardless of
      // what this says, so a stale/cleared localStorage value can't be
      // used to bypass the cap the way it could before.
      const today = new Date().toISOString().slice(0, 10);
      let used = { day: today, n: 0 };
      try {
        const raw = localStorage.getItem(USAGE);
        if (raw) used = JSON.parse(raw) as { day: string; n: number };
      } catch { /* ignore */ }
      if (used.day !== today) used = { day: today, n: 0 };
      const result = await deepResearchFn({
        data: {
          name: company.name,
          website: company.website,
          vertical: company.vertical,
          city: company.city,
          phone: company.phone,
          google_rating: company.google_rating,
          review_count: company.review_count,
          locations_count: company.locations_count,
          years_in_business: company.years_in_business,
          score: company.score,
          research_status: company.research_status,
          findings: company.findings,
        },
      });
      if (result.hunter_ran) {
        used.n += 1;
        localStorage.setItem(USAGE, JSON.stringify(used));
      }
      setRows((prev) => applyByUid(prev, uid, (c) => {
        const keep = new Set(["provider", "place_id", "maps_url", "address", "category", "business_status", "coordinates", "job_value_est"]);
        const preserved = (c.facts || []).filter((f) => keep.has(f.key) && !(result.facts || []).some((r) => r.key === f.key));
        return {
        ...c,
        facts: [...preserved, ...result.facts],
        contacts: result.contacts,
        ads: result.ads,
        socials: result.socials,
        readiness: result.readiness,
        readiness_why: result.readiness_why,
        company_kind: result.company_kind,
        website_note: result.website_note,
        hunter_skipped_reason: result.hunter_skipped_reason,
        deep_at: new Date().toISOString(),
        estimated_cents: result.estimated_cents,
        pages_fetched: result.pages_fetched,
      };
      }));
    } catch {
      setDeepErr("Deep research didn’t finish. We did not invent contacts or ads. Press Try again, or Skip.");
    } finally {
      setDeepBusy(false);
    }
  }

  async function runFind(opts?: { vertical?: string; location?: string; limit?: number }) {
    const v = opts?.vertical || vert;
    const loc = opts?.location || city;
    const n = opts?.limit || findLimit;
    setFindBusy(true);
    setFindMsg("");
    try {
      const result = await findClientsFn({
        data: { vertical: v, location: loc, limit: n, radiusM: 40000, minRating, minReviews },
      });
      if (!result.ok) {
        setFindMsg(result.reason);
        say(result.reason);
        return;
      }
      setRows(result.prospects);
      saveCompanies(result.prospects);
      setFindMsg(result.reason);
      setView("pipe");
      say(result.reason);
    } catch {
      const msg = "Lamb Ascension couldn’t save this change to the server. Your local copy is still safe.";
      setFindMsg(msg);
      setSyncErr(msg);
    } finally {
      setFindBusy(false);
    }
  }

  function addClient(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setErr("I need the company name. Type it, then Save."); return; }
    const created = ensureUid({
      id: nextClientId(rows),
      uid: newUid(),
      name: name.trim(), vertical: vert, city, website: web, review_count: 0, google_rating: "UNKNOWN",
      phone: "UNKNOWN", job_value_est: 0, job_value_kind: "UNKNOWN", score: 45, fit: "possible", fit_plain: FIT.possible,
      stage: "New", stage_plain: STAGE.New, research_status: web ? "queued" : "none", findings: [],
    });
    setRows((prev) => [...prev, created]);
    setName(""); setWeb(""); setView("home");
  }

  const open = findByUid(rows, openUid);

  if (isPending) {
    // Session is still resolving (Better Auth's useSession hook) — render
    // nothing rather than flashing the sign-in form for an already-signed-in
    // owner on every reload.
    return null;
  }

  if (!user) {
    return (
      <main className="mx-auto max-w-md px-4 py-16">
        <form onSubmit={signIn} className="rounded-[14px] border border-line bg-surface p-6">
          <p className="text-gold text-sm">Lamb Ascension</p>
          <h1 className="font-display mt-1 mb-2 text-3xl">Sign in</h1>
          <p className="mb-4 text-sm text-muted">This is your agency desk. You'll only see what needs you.</p>
          <label className="mb-1 block text-sm text-muted" htmlFor="em">Email</label>
          <input id="em" className="mb-3 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
          <label className="mb-1 block text-sm text-muted" htmlFor="pw">Password</label>
          <input id="pw" type="password" className="mb-4 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
          <div className="flex flex-wrap gap-2">
            <button type="submit" className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" disabled={busy}>
              {busy ? "Signing in…" : "Enter"}
            </button>
            <button type="button" className="min-h-11 rounded-lg border border-line px-4" onClick={() => setExplain("Sign in with the owner email and password. This desk does not create accounts from the browser. Wrong details show the same message — we do not reveal whether an email exists.")}>
              Explain this to me
            </button>
          </div>
          {err ? <div className="mt-4 rounded-xl border border-bad/40 bg-[#2a1414] p-3 text-sm">{err}</div> : null}
        </form>
        {explain ? <Sheet text={explain} onClose={() => setExplain(null)} /> : null}
      </main>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 flex flex-wrap items-center justify-between gap-3 border-b border-line bg-[#0e1219] px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="font-display grid size-9 place-items-center border border-gold text-xs text-gold">LA</div>
          <div>
            <div className="font-display">Lamb Ascension</div>
            <div className="text-xs text-muted">Owner Mode</div>
          </div>
        </div>
        <nav className="flex flex-wrap gap-2">
          {(["home", "add", "pipe"] as const).map((v) => (
            <button key={v} className={`min-h-11 rounded-lg border px-3 ${view === v ? "border-gold bg-gold font-semibold text-[#16120a]" : "border-line"}`}
              onClick={() => setView(v)}>{v === "home" ? "Home" : v === "add" ? "Add Client" : "Pipeline"}</button>
          ))}
          <button
            className="min-h-11 rounded-lg border border-line px-3"
            disabled={busy}
            onClick={() => {
              setBusy(true);
              // realSignOut() clears the real server session (cookie or, in
              // live preview, the bearer token) — not a localStorage flag,
              // so this actually ends the session rather than just hiding
              // the UI.
              void realSignOut().catch(() => setBusy(false));
            }}
          >
            Sign out
          </button>
        </nav>
      </header>
      <div className="mx-auto max-w-3xl px-4 pt-3">
        <VoiceBar
          mode={voiceMode}
          onMode={(m) => { setVoiceMode(m); if (m === "off") { stopSpeaking(); gateRef.current.cancel(); } }}
          listening={voiceListening}
          you={youSaid}
          reply={voiceReply}
          muted={voiceMuted}
          onMuted={setVoiceMuted}
          onTranscript={onVoiceTranscript}
          onListening={setVoiceListening}
          onStop={() => { setVoiceMode("off"); setVoiceListening(false); stopSpeaking(); gateRef.current.cancel(); say("Okay. Stopped."); }}
        />
        {voiceReply ? (
          <button className="mt-2 min-h-11 rounded-lg border border-line px-3 text-sm" onClick={() => setExplain(voiceReply)}>Explain more</button>
        ) : null}
      </div>
      <main className="mx-auto max-w-3xl px-4 py-4 pb-20">
        {syncErr ? <div className="mb-3 rounded-xl border border-bad/40 bg-[#2a1414] p-3 text-sm">{syncErr}</div> : null}
        {view === "home" ? (
          <>
            <div className={`mb-3 rounded-xl border p-3 ${light === "red" ? "border-[#7a3b3b] bg-[#2a1414]" : light === "yellow" ? "border-[#7a6418] bg-[#2a220e]" : "border-[#2e6b4a] bg-[#13271c]"}`}>
              <b>{headline}</b>
              <div className="text-sm">{blurb}</div>
            </div>
            <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
              <Stat n={Math.max(0, rows.length - tasks.filter((t) => t.severity === "red").length)} l="Looking fine" />
              <Stat n={tasks.filter((t) => t.severity === "yellow").length} l="Needs you" />
              <Stat n={tasks.filter((t) => t.severity === "red").length} l="Needs attention" />
            </div>
            <section className="mb-4 rounded-[14px] border border-line bg-surface p-5">
              <h2 className="font-display text-xl">Sales</h2>
              <p className="text-sm">{sales.ready} prospects ready to contact</p>
              <p className="text-sm">{sales.followups} follow-ups running</p>
              <p className="text-sm">{sales.replies} replies need you</p>
              <p className="text-sm">{sales.calls} calls booked</p>
            </section>
            <section className="mb-4 rounded-[14px] border border-line bg-surface p-5">
              <h2 className="font-display text-xl">Connections</h2>
              <p className="text-sm">{google.gmail === "connected" ? "🟢 Gmail connected" : google.gmail === "attention" ? "🟡 Gmail needs attention" : "🔴 Gmail not connected"}</p>
              <p className="text-sm">{google.calendar === "connected" ? "🟢 Calendar connected" : google.calendar === "attention" ? "🟡 Calendar needs attention" : "🔴 Calendar not connected"}</p>
              {google.error ? <p className="mt-2 text-sm">🔴 {google.error} No emails were sent while it was disconnected.</p> : null}
              <div className="mt-3 flex flex-wrap gap-2">
                <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" onClick={() => void connectGoogle("gmail")}>Connect Gmail</button>
                <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => void connectGoogle("calendar")}>Connect Google Calendar</button>
              </div>
            </section>
            <section className="mb-4 rounded-[14px] border border-line bg-surface p-5">
              <h2 className="font-display text-xl">What should I do?</h2>
              <p className="mb-3 text-sm text-muted">
                {readyN ? `You have ${readyN} prospect${readyN === 1 ? "" : "s"} ready to contact.` : "I’ll walk you through one thing at a time."}
              </p>
              <div className="flex flex-wrap gap-2">
                <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" onClick={() => setTaskIx(tasks.length ? 0 : null)}>Start My Tasks</button>
                <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => setView("find")}>Find Clients</button>
                <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => setView("add")}>Add Client</button>
                <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => setExplain("Start My Tasks walks one thing at a time: review a company, skip a blocked site, or add someone you already know.")}>Explain this to me</button>
              </div>
            </section>
            <section className="rounded-[14px] border border-line bg-surface p-5">
              <h3 className="font-display mb-2 text-lg">Waiting on you</h3>
              {tasks.slice(0, 6).map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-3 border-b border-line py-3">
                  <div>
                    <b>{t.title}</b>
                    <div className="text-sm text-muted">{t.plain}</div>
                  </div>
                  <button className="min-h-11 shrink-0 rounded-lg bg-gold px-3 font-semibold text-[#16120a]" onClick={() => runTask(t)}>{t.button}</button>
                </div>
              ))}
              {!tasks.length ? <p className="text-muted">Nothing in line.</p> : null}
            </section>
          </>
        ) : null}

        {view === "find" ? (
          <form
            className="rounded-[14px] border border-line bg-surface p-5"
            onSubmit={(e) => { e.preventDefault(); void runFind(); }}
          >
            <h2 className="font-display text-2xl">Find Clients</h2>
            <p className="mb-3 text-sm text-muted">We’ll look up real companies. We will not invent names.</p>
            <label className="block text-sm text-muted">What kind of company?</label>
            <select className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={vert} onChange={(e) => setVert(e.target.value)}>
              {["Roofing", "HVAC", "Plumbing / sewer", "Foundation repair", "Solar", "Med spa / cosmetic", "Dental", "Law / personal injury", "B2B consulting", "SaaS / software", "Other"].map((x) => <option key={x}>{x}</option>)}
            </select>
            <label className="block text-sm text-muted">Where?</label>
            <input className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={city} onChange={(e) => setCity(e.target.value)} placeholder="Dallas, Fort Worth, …" />
            <label className="block text-sm text-muted">How many?</label>
            <input className="mb-3 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" type="number" min={1} max={50} value={findLimit} onChange={(e) => setFindLimit(Number(e.target.value) || 10)} />
            <button type="button" className="mb-3 text-sm text-gold" onClick={() => setFindMore((v) => !v)}>{findMore ? "Hide extra filters" : "More"}</button>
            {findMore ? (
              <div className="mb-3 grid gap-2">
                <label className="text-sm text-muted">Minimum rating <input className="ml-2 w-20 rounded border border-line bg-surface2 px-2" type="number" min={0} max={5} step={0.5} value={minRating} onChange={(e) => setMinRating(Number(e.target.value) || 0)} /></label>
                <label className="text-sm text-muted">Minimum reviews <input className="ml-2 w-20 rounded border border-line bg-surface2 px-2" type="number" min={0} value={minReviews} onChange={(e) => setMinReviews(Number(e.target.value) || 0)} /></label>
              </div>
            ) : null}
            {findMsg ? <p className="mb-2 text-sm">{findMsg}</p> : null}
            <div className="flex flex-wrap gap-2">
              <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" type="submit" disabled={findBusy}>
                {findBusy ? "Looking…" : "Find Clients"}
              </button>
              <button className="min-h-11 rounded-lg border border-line px-4" type="button" onClick={() => setView("add")}>Add one I already know</button>
              <button className="min-h-11 rounded-lg border border-line px-4" type="button" onClick={() => setView("home")}>Cancel</button>
            </div>
          </form>
        ) : null}

        {view === "add" ? (
          <form onSubmit={addClient} className="rounded-[14px] border border-line bg-surface p-5">
            <h2 className="font-display text-2xl">Add Client</h2>
            <p className="mb-3 text-sm text-muted">Use this when you already know the company.</p>
            <label className="block text-sm text-muted">Company name</label>
            <input className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={name} onChange={(e) => setName(e.target.value)} />
            <label className="block text-sm text-muted">What they do</label>
            <select className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={vert} onChange={(e) => setVert(e.target.value)}>
              {["Roofing", "HVAC", "Plumbing / sewer", "Foundation repair", "Solar", "Med spa / cosmetic", "Dental", "Law / personal injury", "B2B consulting", "SaaS / software", "Other"].map((x) => <option key={x}>{x}</option>)}
            </select>
            <label className="block text-sm text-muted">Website</label>
            <input className="mb-2 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={web} onChange={(e) => setWeb(e.target.value)} placeholder="https://" />
            <label className="block text-sm text-muted">City</label>
            <input className="mb-4 min-h-11 w-full rounded-lg border border-line bg-surface2 px-3" value={city} onChange={(e) => setCity(e.target.value)} />
            {err ? <p className="mb-2 text-sm text-bad">{err}</p> : null}
            <div className="flex gap-2">
              <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" type="submit">Save</button>
              <button className="min-h-11 rounded-lg border border-line px-4" type="button" onClick={() => setView("home")}>Cancel</button>
            </div>
          </form>
        ) : null}

        {view === "pipe" ? (
          <section className="rounded-[14px] border border-line bg-surface p-5">
            <h2 className="font-display mb-2 text-2xl">Pipeline</h2>
            {rows.map((c) => (
              <button key={c.uid || c.id} className="flex w-full items-center justify-between border-b border-line py-3 text-left" onClick={() => { setOpenUid(c.uid || null); setEvidence(false); setAdvanced(false); setView("detail"); }}>
                <span><b>{c.name}</b><span className="block text-sm text-muted">{c.stage_plain} · {c.fit_plain}</span></span>
                <span className="text-gold">{c.score}</span>
              </button>
            ))}
          </section>
        ) : null}

        {view === "outreach" && open ? (
          <OutreachDesk
            company={open}
            onSave={patchCompany}
            onExplain={setExplain}
            onBack={() => setView("home")}
            onCall={() => setView("call")}
            onPrep={() => setView("prep")}
            onSend={() => void doSend(open, "MANUAL")}
            gmailConnected={google.gmail === "connected"}
          />
        ) : null}
        {view === "call" && open ? <CallCard company={open} onBack={() => setView("outreach")} /> : null}
        {view === "prep" && open ? (
          <PrepCard company={open} onSave={patchCompany} onBack={() => setView("home")} />
        ) : null}
        {view === "detail" && open ? (
          <ReviewPage
            company={open}
            evidence={evidence}
            advanced={advanced}
            busy={deepBusy}
            err={deepErr}
            onEvidence={() => setEvidence((v) => !v)}
            onAdvanced={() => setAdvanced((v) => !v)}
            onExplain={() => setExplain(explainCompany(open))}
            onApprove={() => approveProspect(open, "MANUAL")}
            onSkip={() => skipProspect(open, "MANUAL")}
            onResearch={() => researchFurther(open.uid || "")}
            onBack={() => setView("home")}
          />
        ) : null}
      </main>

      {taskIx !== null && tasks[taskIx] ? (
        <Sheet
          title={`Task ${taskIx + 1} of ${tasks.length}`}
          heading={tasks[taskIx].title}
          text={`What happened: ${tasks[taskIx].plain}\n\nWhy it matters: ${tasks[taskIx].why}\n\nWhat I recommend: ${tasks[taskIx].recommend}`}
          onClose={() => setTaskIx(null)}
        >
          <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" onClick={() => runTask(tasks[taskIx])}>{tasks[taskIx].button}</button>
          <button className="min-h-11 rounded-lg border border-line px-4" onClick={() => setTaskIx(taskIx + 1)}>Skip this</button>
        </Sheet>
      ) : null}
      {explain ? <Sheet text={explain} onClose={() => setExplain(null)} /> : null}
    </div>
  );
}

function ReviewPage({
  company, evidence, advanced, busy, err, onEvidence, onAdvanced, onExplain, onApprove, onSkip, onResearch, onBack,
}: {
  company: Prospect;
  evidence: boolean;
  advanced: boolean;
  busy: boolean;
  err: string;
  onEvidence: () => void;
  onAdvanced: () => void;
  onExplain: () => void;
  onApprove: () => void;
  onSkip: () => void;
  onResearch: () => void;
  onBack: () => void;
}) {
  const found = importantFindings(company);
  const opps = opportunities(company);
  const value = highValueTake(company);
  const offer = recommendOffer(company);
  const named = (company.contacts || []).filter((c) => c.name && c.name !== "UNKNOWN");
  const primaryApprove = approveIsPrimary(company);
  const ads = company.ads || [];

  return (
    <div className="space-y-4">
      <section className="rounded-[14px] border border-line bg-surface p-5">
        <p className="text-sm text-gold">Prospect review</p>
        <h2 className="font-display text-2xl">{company.name}</h2>
        <p className="text-sm text-muted">{company.vertical} · {company.city}{company.review_count ? ` · ${company.review_count} public reviews` : ""}{company.google_rating && company.google_rating !== "UNKNOWN" ? ` · ${company.google_rating} rating` : ""}</p>
        <p className="mt-2 text-sm">{company.stage_plain}</p>
        {company.website_note ? <p className="mt-2 rounded-lg border border-[#7a6418] bg-[#2a220e] p-3 text-sm">{company.website_note}</p> : null}
      </section>

      <Block title="1. Why consider them?">
        <p>{whyConsider(company)}</p>
      </Block>

      <Block title="2. What did we find?">
        <ul className="space-y-2">
          {found.map((f) => (
            <li key={f.label}><b>{f.label}:</b> {f.plain}</li>
          ))}
        </ul>
        {ads.length ? (
          <div className="mt-3 text-sm">
            <b>Advertising:</b>
            <ul className="mt-1 space-y-1">
              {ads.map((a) => (
                <li key={a.network + a.source}>{a.network}: {a.label}. {a.detail}</li>
              ))}
            </ul>
          </div>
        ) : null}
      </Block>

      <Block title="3. What could Lamb Ascension help with?">
        {opps.length ? (
          <ul className="space-y-3">
            {opps.map((o) => (
              <li key={o.code}>
                <b>{o.title}</b>
                <div className="text-sm text-muted">{o.plain}</div>
              </li>
            ))}
          </ul>
        ) : (
          <p>No pitchable on-page opportunity from the research we actually have. We will not invent one.</p>
        )}
      </Block>

      <Block title="4. Could this be worth pursuing for the high-value offer?">
        <p className="mb-2 font-semibold">{value.verdict}</p>
        <p className="text-sm">This is a research class, not a claim they can pay $10,000/month. Review count is optional — it is not the only way in.</p>
        <p className="mb-1 mt-2 text-sm text-muted">Why:</p>
        <ul className="mb-2 list-disc pl-5 text-sm">{value.evidence.map((x) => <li key={x}>{x}</li>)}</ul>
        <p className="mb-1 text-sm text-muted">What we still don’t know:</p>
        <ul className="list-disc pl-5 text-sm">{value.unknown.map((x) => <li key={x}>{x}</li>)}</ul>
      </Block>

      <Block title="5. Who should I contact?">
        {named.length ? (
          <ul className="space-y-2">
            {named.map((c) => (
              <li key={c.name + c.source}>
                <b>{c.name}</b>{c.title && c.title !== "UNKNOWN" ? ` — ${c.title}` : ""}
                <div className="text-sm text-muted">
                  {c.email ? `${c.email} (${c.email_status})` : "No business email on file"}
                  {c.profile_url ? ` · ${c.profile_url}` : ""}
                </div>
                <div className="text-xs text-muted">Source: {c.source}</div>
              </li>
            ))}
          </ul>
        ) : (
          <p>UNKNOWN. We do not have a verified person yet. We will not guess a name or email.{company.hunter_skipped_reason ? ` ${company.hunter_skipped_reason}` : ""}</p>
        )}
      </Block>

      <Block title="6. What should I sell them?">
        <p className="mb-1"><b>{offer.name === "Unknown" ? "No offer yet" : offer.name}</b></p>
        <p className="text-sm">{offer.why}</p>
      </Block>

      <Block title="7. What should I do next?">
        <p className="mb-3">{nextStepLabel(company)}</p>
        {err ? <div className="err mb-3 rounded-xl border border-bad/40 bg-[#2a1414] p-3 text-sm">{err}</div> : null}
        <div className="flex flex-wrap gap-2">
          <button className={`min-h-11 rounded-lg px-4 font-semibold ${primaryApprove ? "border border-line" : "bg-gold text-[#16120a]"}`} onClick={onResearch} disabled={busy}>
            {busy ? "Researching…" : "Research further"}
          </button>
          <button className={`min-h-11 rounded-lg px-4 font-semibold ${primaryApprove ? "bg-gold text-[#16120a]" : "border border-line"}`} onClick={onApprove}>
            Approve for outreach
          </button>
          <button className="min-h-11 rounded-lg border border-line px-4" onClick={onSkip}>Skip</button>
          <button className="min-h-11 rounded-lg border border-line px-4" onClick={onEvidence}>{evidence ? "Hide evidence" : "See evidence"}</button>
          <button className="min-h-11 rounded-lg border border-line px-4" onClick={onExplain}>Explain this to me</button>
          <button className="min-h-11 rounded-lg border border-line px-4" onClick={onBack}>Back</button>
        </div>
      </Block>

      {evidence ? (
        <Block title="Evidence (what we actually stored)">
          {(company.facts || []).map((f) => (
            <div key={f.key + f.source} className="border-b border-line py-2 text-sm">
              <b>{f.key}</b> · {f.status}<div className="text-muted">{f.value} · {f.source} · {f.checked_at}</div>
            </div>
          ))}
          {company.provider_place_id ? (
            <div className="border-b border-line py-2 text-sm">
              <b>Google listing</b>
              <div className="text-muted">Place ID: {company.provider_place_id}</div>
              {company.provider_source_url ? <div className="text-muted">Maps: {company.provider_source_url}</div> : null}
              {company.address ? <div className="text-muted">Address: {company.address}</div> : null}
              {company.provider_category ? <div className="text-muted">Category: {company.provider_category}</div> : null}
              {company.business_status ? <div className="text-muted">Listing status: {company.business_status}</div> : null}
            </div>
          ) : null}
          {company.findings.map((f, i) => (
            <div key={f.id + i} className="border-b border-line py-2 text-sm">
              <b>{f.id}</b> · {f.status}<div className="text-muted">{f.result}{f.source ? ` · ${f.source}` : ""}</div>
            </div>
          ))}
          <button className="mt-3 min-h-11 rounded-lg border border-line px-4" onClick={onAdvanced}>{advanced ? "Hide advanced" : "Advanced (cost & APIs)"}</button>
        </Block>
      ) : null}

      {advanced && evidence ? (
        <Block title="Advanced">
          <pre className="overflow-auto text-xs text-muted">{JSON.stringify({
            research_status: company.research_status,
            score: company.score,
            pages_fetched: company.pages_fetched ?? 0,
            estimated_cents: company.estimated_cents ?? 0,
            hunter_skipped_reason: company.hunter_skipped_reason || "",
            provider: company.provider || "",
            provider_place_id: company.provider_place_id || "",
            job_value_est: company.job_value_est,
            job_value_kind: company.job_value_kind || "UNKNOWN",
            note: "job_value_est is an INDUSTRY_ESTIMATE, not Google-provided revenue. Paid contact lookup only runs after a prospect already looks promising. Revenue stays UNKNOWN.",
          }, null, 2)}</pre>
        </Block>
      ) : null}
    </div>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-[14px] border border-line bg-surface p-5">
      <h3 className="font-display mb-2 text-lg">{title}</h3>
      {children}
    </section>
  );
}

function Stat({ n, l }: { n: number; l: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface2 p-4">
      <b className="font-display text-2xl text-gold2">{n}</b>
      <div className="text-sm text-muted">{l}</div>
    </div>
  );
}

function Sheet({ title, heading, text, onClose, children }: { title?: string; heading?: string; text: string; onClose: () => void; children?: ReactNode }) {
  return (
    <div className="fixed inset-0 z-20 flex items-end bg-black/70 p-3" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="mx-auto w-full max-w-3xl rounded-t-2xl border border-line bg-surface p-5">
        {title ? <p className="text-sm text-muted">{title}</p> : null}
        {heading ? <h2 className="font-display mb-2 text-xl">{heading}</h2> : <h2 className="font-display mb-2 text-xl">Explain this to me</h2>}
        <p className="mb-4 whitespace-pre-wrap text-sm">{text}</p>
        <div className="flex flex-wrap gap-2">
          {children}
          <button className="min-h-11 rounded-lg bg-gold px-4 font-semibold text-[#16120a]" onClick={onClose}>Got it</button>
        </div>
      </div>
    </div>
  );
}
