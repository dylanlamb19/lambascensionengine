import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/jobs/outreach")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { allowOutreachJob } = await import("@/lib/mail/job-auth");
        const { isWorkspacePreview } = await import("@/lib/env.server");
        const gate = allowOutreachJob({
          secret: process.env.OUTREACH_JOB_SECRET,
          header: request.headers.get("x-job-secret") || "",
          production: !isWorkspacePreview(),
        });
        if (!gate.ok) return new Response(gate.body, { status: gate.status });
        const { tickOutreachWorker } = await import("@/lib/mail/live.server");
        await tickOutreachWorker();
        return Response.json({ ok: true });
      },
    },
  },
});
