import { timingSafeEqual } from "node:crypto";

export function secretsEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return timingSafeEqual(ba, bb);
}

/**
 * HTTP worker endpoint is fail-closed: a missing secret never runs jobs.
 * Preview uses the in-process tick, not this unauthenticated route.
 */
export function allowOutreachJob(opts: {
  secret: string | undefined;
  header: string;
  production?: boolean;
}): { ok: true } | { ok: false; status: number; body: string } {
  void opts.production;
  const secret = (opts.secret || "").trim();
  if (!secret) {
    return {
      ok: false,
      status: 503,
      body: "Outreach jobs are not configured. Set OUTREACH_JOB_SECRET. No emails were sent.",
    };
  }
  if (!secretsEqual(secret, opts.header || "")) {
    return { ok: false, status: 401, body: "forbidden" };
  }
  return { ok: true };
}
