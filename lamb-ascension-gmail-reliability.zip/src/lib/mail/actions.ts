import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { InputMethod } from "./types";

function recipientOf(p: { contacts?: { email?: string }[]; name: string }): string {
  const hit = (p.contacts || []).find((c) => c.email && c.email !== "UNKNOWN" && c.email.includes("@"));
  return hit?.email || "";
}

export const googleStatusFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { googleStatus } = await import("./sql.server");
    const { googleOAuthConfigured } = await import("../google/oauth");
    const status = await googleStatus(context.userId);
    return { ok: true as const, configured: googleOAuthConfigured(), ...status };
  });

export const googleStartFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { kind: "gmail" | "calendar"; origin: string }) => data)
  .handler(async ({ data, context }) => {
    const { googleOAuthConfigured, authorizeUrl } = await import("../google/oauth");
    if (!googleOAuthConfigured()) {
      return {
        ok: false as const,
        reason: "Google isn’t set up on this server yet. We will not ask for your Gmail password. Whoever hosts Lamb Ascension needs to add the Google OAuth keys.",
      };
    }
    const { saveOauthState } = await import("./sql.server");
    const rec = await saveOauthState(context.userId, data.kind);
    const url = authorizeUrl({ state: rec.state, kind: data.kind, requestUrl: data.origin });
    return { ok: true as const, url };
  });

export const googleDisconnectFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { kind: "gmail" | "calendar" }) => data)
  .handler(async ({ data, context }) => {
    const { disconnectGoogle, audit } = await import("./sql.server");
    await disconnectGoogle(context.userId, data.kind);
    await audit(context.userId, "google_disconnect", `Disconnected ${data.kind}`, { method: "MANUAL" });
    return { ok: true as const };
  });

export const salesCountsFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { salesCounts } = await import("./sql.server");
    return { ok: true as const, ...(await salesCounts(context.userId)) };
  });

export const sendFirstEmailFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string; method?: InputMethod; approveSequence?: boolean }) => data)
  .handler(async ({ data, context }) => {
    const { getProspectByUid } = await import("@/lib/prospects/repo.server");
    const prospect = await getProspectByUid(context.userId, data.uid);
    if (!prospect) return { ok: false as const, reason: "That company is not on your list." };
    const to = recipientOf(prospect);
    const pack = prospect.outreach;
    const email = pack?.messages.find((m) => m.kind === "email");
    if (!email) return { ok: false as const, reason: "There is no approved draft yet." };
    const { sendLive } = await import("./live.server");
    const sent = await sendLive({
      userId: context.userId,
      prospect,
      kind: "email",
      method: data.method || "MANUAL",
      to,
      subject: email.subject || `Quick note — ${prospect.name}`,
      body: email.body,
      firstApproved: true,
    });
    if (!sent.ok) return sent;
    if (data.approveSequence) {
      const { saveSequence } = await import("./sql.server");
      const f1 = pack?.messages.find((m) => m.kind === "followup1")?.body || "";
      const f2 = pack?.messages.find((m) => m.kind === "followup2")?.body || "";
      const f3 = pack?.messages.find((m) => m.kind === "followup3")?.body || "";
      const now = Date.now();
      await saveSequence(context.userId, prospect.uid || data.uid, data.method || "MANUAL", [
        { step: "followup1", dueAt: now + 3 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup1`, body: f1, subject: email.subject || prospect.name, recipient: to, threadId: sent.threadId },
        { step: "followup2", dueAt: now + 7 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup2`, body: f2, subject: email.subject || prospect.name, recipient: to, threadId: sent.threadId },
        { step: "followup3", dueAt: now + 12 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup3`, body: f3, subject: email.subject || prospect.name, recipient: to, threadId: sent.threadId },
      ]);
    }
    return sent;
  });

export const approveSequenceFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string; method?: InputMethod }) => data)
  .handler(async ({ data, context }) => {
    const { getProspectByUid } = await import("@/lib/prospects/repo.server");
    const { saveSequence, lastThread, audit } = await import("./sql.server");
    const prospect = await getProspectByUid(context.userId, data.uid);
    if (!prospect) return { ok: false as const, reason: "That company is not on your list." };
    const to = recipientOf(prospect);
    const pack = prospect.outreach;
    const email = pack?.messages.find((m) => m.kind === "email");
    if (!email) return { ok: false as const, reason: "Approve and send the first email before the sequence." };
    const threadId = await lastThread(context.userId, data.uid);
    const now = Date.now();
    const id = await saveSequence(context.userId, data.uid, data.method || "MANUAL", [
      { step: "followup1", dueAt: now + 3 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup1`, body: pack?.messages.find((m) => m.kind === "followup1")?.body || "", subject: email.subject || prospect.name, recipient: to, threadId },
      { step: "followup2", dueAt: now + 7 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup2`, body: pack?.messages.find((m) => m.kind === "followup2")?.body || "", subject: email.subject || prospect.name, recipient: to, threadId },
      { step: "followup3", dueAt: now + 12 * 86400000, idempotencyKey: `${context.userId}:${data.uid}:followup3`, body: pack?.messages.find((m) => m.kind === "followup3")?.body || "", subject: email.subject || prospect.name, recipient: to, threadId },
    ]);
    await audit(context.userId, "approve_sequence", "Approved 3 follow-ups over 12 days", { prospectUid: data.uid, method: data.method || "MANUAL", sequenceId: id });
    return { ok: true as const, sequenceId: id };
  });

export const stopSequenceFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string }) => data)
  .handler(async ({ data, context }) => {
    const { stopSequencesForProspect, audit } = await import("./sql.server");
    await stopSequencesForProspect(context.userId, data.uid);
    await audit(context.userId, "stop_sequence", "Stopped follow-ups", { prospectUid: data.uid });
    return { ok: true as const };
  });

export const syncRepliesFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { syncRepliesForUser } = await import("./live.server");
    return syncRepliesForUser(context.userId);
  });

export const availabilityFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { accessFor } = await import("./live.server");
    const { listBusy } = await import("../google/calendar");
    const { openSlots } = await import("../calendar/slots");
    const tokens = await accessFor(context.userId, "calendar");
    if (!tokens) return { ok: false as const, reason: "Calendar is not connected.", slots: [] as { start: string; end: string; label: string }[] };
    const from = new Date();
    const to = new Date(from.getTime() + 14 * 86400000);
    const busy = await listBusy(tokens.access_token, from, to);
    const slots = openSlots({ from, busy, count: 3 }).map((s) => ({ start: s.start.toISOString(), end: s.end.toISOString(), label: s.label }));
    return { ok: true as const, slots };
  });

export const scheduleCallFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string; start: string; end: string; method?: InputMethod }) => data)
  .handler(async ({ data, context }) => {
    const { getProspectByUid } = await import("@/lib/prospects/repo.server");
    const { accessFor } = await import("./live.server");
    const { saveCalendarEvent, audit } = await import("./sql.server");
    const { createEvent } = await import("../google/calendar");
    const prospect = await getProspectByUid(context.userId, data.uid);
    if (!prospect) return { ok: false as const, reason: "That company is not on your list." };
    const tokens = await accessFor(context.userId, "calendar");
    if (!tokens) return { ok: false as const, reason: "Calendar needs to be reconnected. No meeting was created." };
    const start = new Date(data.start);
    const end = new Date(data.end);
    const created = await createEvent(tokens.access_token, {
      title: `Lamb Ascension / ${prospect.name}`,
      start,
      end,
      description: "Sales call. Do not claim revenue, ad spend, or $10K ability.",
    });
    if (!created.ok) return { ok: false as const, reason: created.error };
    await saveCalendarEvent(context.userId, data.uid, created.id, `Call with ${prospect.name}`, start, end);
    await audit(context.userId, "schedule_call", `Booked ${start.toISOString()}`, { prospectUid: data.uid, method: data.method || "MANUAL", providerIds: created.id });
    return { ok: true as const, eventId: created.id };
  });

export const bookingLinkFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string; origin: string }) => data)
  .handler(async ({ data, context }) => {
    const { createBookingLink } = await import("./sql.server");
    const token = await createBookingLink(context.userId, data.uid);
    return { ok: true as const, url: `${data.origin}/book/${token}` };
  });

export const timelineFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { uid: string }) => data)
  .handler(async ({ data, context }) => {
    const { timeline } = await import("./sql.server");
    return { ok: true as const, events: await timeline(context.userId, data.uid) };
  });

export const nextCallFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { nextCall } = await import("./sql.server");
    return { ok: true as const, call: await nextCall(context.userId) };
  });
