create unique index if not exists outreach_sequences_one_active
  on outreach_sequences (user_id, prospect_uid) where status = 'active';
